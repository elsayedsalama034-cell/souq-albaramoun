# دليل إخراج التطبيق

1. ثبّت Flutter وAndroid Studio على جهاز كمبيوتر.
2. افتح مجلد المشروع.
3. نفّذ `flutter pub get`.
4. ضع ملف إعداد Firebase الصحيح للتطبيق في `android/app/google-services.json`.
5. نفّذ `flutter run` واختبر التطبيق على هاتف حقيقي.
6. للإصدار التجريبي: `flutter build apk --release`.
7. للنشر في Google Play: `flutter build appbundle --release`.

> لا تنشر التطبيق قبل اختبار تسجيل الدخول، Firestore، Storage والصلاحيات.
