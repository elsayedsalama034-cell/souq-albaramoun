-- قاعدة بيانات منصتي
-- شغّل هذا الملف داخل محرر SQL في مشروع Supabase بعد إنشاء المشروع.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text unique,
  status text not null default 'نشط',
  phone_verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.roles (
  id bigint generated always as identity primary key,
  name text unique not null
);

create table if not exists public.user_roles (
  user_id uuid references auth.users(id) on delete cascade,
  role_id bigint references public.roles(id) on delete cascade,
  primary key(user_id, role_id)
);

create table if not exists public.permissions (
  id bigint generated always as identity primary key,
  name text unique not null
);

create table if not exists public.role_permissions (
  role_id bigint references public.roles(id) on delete cascade,
  permission_id bigint references public.permissions(id) on delete cascade,
  primary key(role_id, permission_id)
);

create table if not exists public.categories (
  id bigint generated always as identity primary key,
  name text not null,
  description text,
  sort_order int not null default 0,
  active boolean not null default true
);

create table if not exists public.subcategories (
  id bigint generated always as identity primary key,
  category_id bigint not null references public.categories(id) on delete cascade,
  name text not null,
  sort_order int not null default 0,
  active boolean not null default true
);

create table if not exists public.plans (
  id bigint generated always as identity primary key,
  name text not null,
  price numeric(12,2) not null,
  duration_days int not null,
  max_ads int not null,
  max_images_per_ad int not null default 10,
  max_videos_per_ad int not null default 1,
  active boolean not null default true
);

create table if not exists public.payment_settings (
  id bigint generated always as identity primary key,
  transfer_number text not null,
  recipient_name text,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists public.payment_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id bigint not null references public.plans(id),
  amount numeric(12,2) not null,
  transaction_number text not null,
  receipt_path text,
  status text not null default 'قيد المراجعة',
  rejection_reason text,
  reviewed_by uuid references auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create unique index if not exists uq_payment_transaction_number
on public.payment_requests(transaction_number)
where status in ('قيد المراجعة','معتمد');

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id bigint not null references public.plans(id),
  payment_request_id uuid unique references public.payment_requests(id),
  start_at timestamptz not null,
  end_at timestamptz not null,
  max_ads int not null,
  max_images_per_ad int not null,
  max_videos_per_ad int not null,
  status text not null default 'فعال',
  created_at timestamptz not null default now()
);

create table if not exists public.ads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  category_id bigint references public.categories(id),
  subcategory_id bigint references public.subcategories(id),
  title text not null,
  description text not null,
  price numeric(14,2),
  governorate text,
  district text,
  status text not null default 'مسودة',
  rejection_reason text,
  published_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ad_images (
  id uuid primary key default gen_random_uuid(),
  ad_id uuid not null references public.ads(id) on delete cascade,
  path text not null,
  sort_order int not null default 0,
  is_primary boolean not null default false
);

create table if not exists public.ad_videos (
  id uuid primary key default gen_random_uuid(),
  ad_id uuid not null references public.ads(id) on delete cascade,
  path text not null,
  duration_seconds int,
  size_bytes bigint
);

create table if not exists public.favorites (
  user_id uuid references auth.users(id) on delete cascade,
  ad_id uuid references public.ads(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, ad_id)
);

create table if not exists public.follows (
  follower_id uuid references auth.users(id) on delete cascade,
  followed_user_id uuid references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(follower_id, followed_user_id)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  title text not null,
  body text not null,
  type text,
  reference_id text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references auth.users(id) on delete cascade,
  ad_id uuid references public.ads(id) on delete cascade,
  reason text not null,
  details text,
  status text not null default 'جديد',
  decision text,
  reviewed_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id),
  action text not null,
  entity_type text,
  entity_id text,
  old_value jsonb,
  new_value jsonb,
  created_at timestamptz not null default now()
);

-- تفعيل الحماية على الجداول التي تحتوي بيانات مستخدمين.
alter table public.profiles enable row level security;
alter table public.payment_requests enable row level security;
alter table public.subscriptions enable row level security;
alter table public.ads enable row level security;
alter table public.favorites enable row level security;
alter table public.follows enable row level security;
alter table public.notifications enable row level security;
alter table public.reports enable row level security;
alter table public.audit_logs enable row level security;

-- سياسات أولية آمنة: المستخدم يرى بياناته فقط.
create policy "المستخدم يرى ملفه" on public.profiles
for select to authenticated using (id = auth.uid());

create policy "المستخدم ينشئ ملفه" on public.profiles
for insert to authenticated with check (id = auth.uid());

create policy "المستخدم يعدل ملفه" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "المستخدم يرى طلبات دفعه" on public.payment_requests
for select to authenticated using (user_id = auth.uid());

create policy "المستخدم ينشئ طلب دفعه" on public.payment_requests
for insert to authenticated with check (user_id = auth.uid());

create policy "المستخدم يرى اشتراكاته" on public.subscriptions
for select to authenticated using (user_id = auth.uid());

create policy "المستخدم يرى إعلاناته" on public.ads
for select to authenticated using (user_id = auth.uid());

create policy "المستخدم ينشئ إعلاناته" on public.ads
for insert to authenticated with check (user_id = auth.uid());

create policy "المستخدم يعدل إعلاناته" on public.ads
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "المستخدم يدير مفضلته" on public.favorites
for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "المستخدم يدير متابعته" on public.follows
for all to authenticated using (follower_id = auth.uid()) with check (follower_id = auth.uid());

create policy "المستخدم يرى إشعاراته" on public.notifications
for select to authenticated using (user_id = auth.uid());

-- مهم: اعتماد الدفع لا يتم من التطبيق مباشرة.
-- يجب تنفيذ الاعتماد عبر وظيفة خادمية محمية بصلاحية الإدارة بعد ربط لوحة الإدارة.
