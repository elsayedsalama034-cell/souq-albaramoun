import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const SouqApp());
}

class SouqApp extends StatelessWidget {
  const SouqApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'سوق البرامون',
      locale: const Locale('ar'),
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.teal,
        scaffoldBackgroundColor: const Color(0xfff7f8fa),
      ),
      builder: (_, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (_, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Splash();
        }
        return snapshot.data == null ? const LoginPage() : const ProfileGate();
      },
    );
  }
}

class Splash extends StatelessWidget {
  const Splash({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final name = TextEditingController();
  final phone = TextEditingController();

  bool create = false;
  bool busy = false;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    name.dispose();
    phone.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      msg('أدخل بيانات الدخول');
      return;
    }

    setState(() => busy = true);
    try {
      UserCredential credential;
      if (create) {
        credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );

        await FirebaseFirestore.instance
            .collection('users')
            .doc(credential.user!.uid)
            .set({
          'name': name.text.trim(),
          'phone': phone.text.trim(),
          'email': email.text.trim(),
          'role': 'زائر',
          'status': 'نشط',
          'createdAt': FieldValue.serverTimestamp(),
        });
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
      }
    } on FirebaseAuthException catch (e) {
      msg({
            'email-already-in-use': 'هذا الحساب موجود بالفعل',
            'invalid-credential': 'بيانات الدخول غير صحيحة',
            'invalid-email': 'البريد الإلكتروني غير صحيح',
            'weak-password': 'كلمة المرور ضعيفة',
            'user-disabled': 'الحساب موقوف',
          }[e.code] ??
          'حدث خطأ في تسجيل الدخول');
    } catch (_) {
      msg('حدث خطأ غير متوقع');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void msg(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Column(
                children: [
                  const Icon(Icons.storefront, size: 76),
                  const SizedBox(height: 10),
                  const Text(
                    'سوق البرامون',
                    style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text(create ? 'إنشاء حساب جديد' : 'تسجيل الدخول'),
                  const SizedBox(height: 20),
                  if (create) ...[
                    field(name, 'الاسم'),
                    const SizedBox(height: 10),
                    field(phone, 'رقم الهاتف', phone: true),
                    const SizedBox(height: 10),
                  ],
                  field(email, 'البريد الإلكتروني', emailField: true),
                  const SizedBox(height: 10),
                  field(password, 'كلمة المرور', secret: true),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: busy ? null : submit,
                      child: Text(
                        busy
                            ? 'جارٍ التنفيذ...'
                            : create
                                ? 'إنشاء الحساب'
                                : 'دخول',
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed:
                        busy ? null : () => setState(() => create = !create),
                    child: Text(
                      create ? 'لدي حساب بالفعل' : 'إنشاء حساب جديد',
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text(
                      'رقم الهاتف محفوظ ضمن الملف الشخصي. لا يتم تخزين كلمات المرور في قاعدة البيانات.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget field(
    TextEditingController controller,
    String label, {
    bool secret = false,
    bool emailField = false,
    bool phone = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: secret,
      keyboardType: phone
          ? TextInputType.phone
          : emailField
              ? TextInputType.emailAddress
              : TextInputType.text,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
    );
  }
}

class ProfileGate extends StatelessWidget {
  const ProfileGate({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .snapshots(),
      builder: (_, snapshot) {
        if (!snapshot.hasData) return const Splash();
        final data = snapshot.data!.data();
        if (data == null) return const CompleteProfile();
        return MainShell(profile: data);
      },
    );
  }
}

class CompleteProfile extends StatelessWidget {
  const CompleteProfile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: FilledButton(
          onPressed: () async {
            final uid = FirebaseAuth.instance.currentUser!.uid;
            await FirebaseFirestore.instance.collection('users').doc(uid).set({
              'name': 'مستخدم',
              'role': 'زائر',
              'status': 'نشط',
              'createdAt': FieldValue.serverTimestamp(),
            });
          },
          child: const Text('إنشاء ملفي الشخصي'),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  final Map<String, dynamic> profile;

  const MainShell({super.key, required this.profile});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeTab(),
      const AdsTab(),
      const SubscriptionTab(),
      AccountTab(profile: widget.profile),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('سوق البرامون'),
        centerTitle: true,
        actions: [
          if (widget.profile['role'] == 'مدير')
            IconButton(
              icon: const Icon(Icons.admin_panel_settings),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AdminPage()),
                );
              },
            ),
        ],
      ),
      body: pages[index],
      floatingActionButton: index == 1 && widget.profile['role'] != 'زائر'
          ? FloatingActionButton.extended(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AddAdPage()),
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('إضافة إعلان'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          NavigationDestination(
            icon: Icon(Icons.campaign_outlined),
            selectedIcon: Icon(Icons.campaign),
            label: 'إعلاناتي',
          ),
          NavigationDestination(
            icon: Icon(Icons.workspace_premium_outlined),
            selectedIcon: Icon(Icons.workspace_premium),
            label: 'الاشتراك',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'حسابي',
          ),
        ],
      ),
    );
  }
}

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            onChanged: (value) => setState(() => query = value.trim()),
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search),
              hintText: 'ابحث في سوق البرامون',
              border: OutlineInputBorder(),
            ),
          ),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance
                .collection('ads')
                .where('status', isEqualTo: 'نشط')
                .snapshots(),
            builder: (_, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }

              final ads = snapshot.data!.docs.where((doc) {
                final data = doc.data();
                return query.isEmpty ||
                    (data['title'] ?? '')
                        .toString()
                        .toLowerCase()
                        .contains(query.toLowerCase()) ||
                    (data['category'] ?? '')
                        .toString()
                        .toLowerCase()
                        .contains(query.toLowerCase());
              }).toList()
                ..sort(
                  (a, b) => ((b.data()['featured'] == true) ? 1 : 0)
                      .compareTo((a.data()['featured'] == true) ? 1 : 0),
                );

              if (ads.isEmpty) {
                return const Center(child: Text('لا توجد إعلانات مطابقة'));
              }

              return ListView.builder(
                itemCount: ads.length,
                itemBuilder: (_, index) {
                  final doc = ads[index];
                  final data = doc.data();

                  return Card(
                    margin:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AdDetailsPage(
                              adId: doc.id,
                              data: data,
                            ),
                          ),
                        );
                      },
                      leading: CircleAvatar(
                        child: Icon(
                          data['featured'] == true
                              ? Icons.star
                              : Icons.campaign,
                        ),
                      ),
                      title: Text(data['title'] ?? 'إعلان'),
                      subtitle: Text(
                        '${data['category'] ?? 'بدون قسم'} • ${data['price'] ?? ''}',
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class AdDetailsPage extends StatelessWidget {
  final String adId;
  final Map<String, dynamic> data;

  const AdDetailsPage({
    super.key,
    required this.adId,
    required this.data,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الإعلان')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if ((data['imageUrl'] ?? '').toString().isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.network(
                data['imageUrl'],
                height: 240,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const SizedBox(height: 240, child: Icon(Icons.image)),
              ),
            ),
          const SizedBox(height: 14),
          Text(
            data['title'] ?? '',
            style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text('القسم: ${data['category'] ?? ''}'),
          Text('السعر: ${data['price'] ?? ''} جنيه'),
          const Divider(height: 30),
          Text(data['description'] ?? 'لا يوجد وصف'),
          const SizedBox(height: 20),
          if (data['featured'] == true)
            const Chip(label: Text('إعلان مميز')),
        ],
      ),
    );
  }
}

class AdsTab extends StatelessWidget {
  const AdsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('ads')
          .where('ownerId', isEqualTo: uid)
          .snapshots(),
      builder: (_, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final ads = snapshot.data!.docs;
        if (ads.isEmpty) {
          return const Center(
            child: Text('لا توجد إعلانات لك. إذا كنت معلنًا أضف إعلانًا.'),
          );
        }

        return ListView(
          children: ads.map((doc) {
            final data = doc.data();

            return Card(
              child: ListTile(
                title: Text(data['title'] ?? ''),
                subtitle: Text('الحالة: ${data['status'] ?? ''}'),
                trailing: PopupMenuButton<String>(
                  itemBuilder: (_) => const [
                    PopupMenuItem(
                      value: 'hide',
                      child: Text('إخفاء'),
                    ),
                    PopupMenuItem(
                      value: 'delete',
                      child: Text('حذف'),
                    ),
                  ],
                  onSelected: (value) async {
                    if (value == 'hide') {
                      await doc.reference.update({'status': 'مخفي'});
                    } else if (value == 'delete') {
                      await doc.reference.delete();
                    }
                  },
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

class AddAdPage extends StatefulWidget {
  const AddAdPage({super.key});

  @override
  State<AddAdPage> createState() => _AddAdPageState();
}

class _AddAdPageState extends State<AddAdPage> {
  final title = TextEditingController();
  final price = TextEditingController();
  final category = TextEditingController();
  final description = TextEditingController();

  bool busy = false;
  XFile? image;

  @override
  void dispose() {
    title.dispose();
    price.dispose();
    category.dispose();
    description.dispose();
    super.dispose();
  }

  Future<void> pickImage() async {
    final selected = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
    if (selected != null && mounted) {
      setState(() => image = selected);
    }
  }

  Future<void> save() async {
    if (title.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتب عنوان الإعلان')),
      );
      return;
    }

    setState(() => busy = true);

    try {
      String imageUrl = '';

      if (image != null) {
        final bytes = await image!.readAsBytes();
        final uid = FirebaseAuth.instance.currentUser!.uid;
        final storageRef = FirebaseStorage.instance
            .ref()
            .child('ad_images')
            .child(uid)
            .child('${DateTime.now().millisecondsSinceEpoch}.jpg');

        await storageRef.putData(
          bytes,
          SettableMetadata(contentType: 'image/jpeg'),
        );
        imageUrl = await storageRef.getDownloadURL();
      }

      await FirebaseFirestore.instance.collection('ads').add({
        'title': title.text.trim(),
        'price': price.text.trim(),
        'category': category.text.trim(),
        'description': description.text.trim(),
        'imageUrl': imageUrl,
        'ownerId': FirebaseAuth.instance.currentUser!.uid,
        'status': 'قيد المراجعة',
        'featured': false,
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم إرسال الإعلان للمراجعة')),
      );
    } on FirebaseException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر حفظ الإعلان: ${e.message ?? e.code}')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر حفظ الإعلان')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة إعلان')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          OutlinedButton.icon(
            onPressed: busy ? null : pickImage,
            icon: const Icon(Icons.photo),
            label: Text(
              image == null ? 'اختيار صورة للإعلان' : 'تم اختيار صورة',
            ),
          ),
          field(title, 'عنوان الإعلان'),
          field(category, 'القسم'),
          field(price, 'السعر'),
          field(description, 'الوصف', lines: 4),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: busy ? null : save,
            child: Text(busy ? 'جارٍ الحفظ...' : 'إرسال الإعلان'),
          ),
        ],
      ),
    );
  }

  Widget field(
    TextEditingController controller,
    String label, {
    int lines = 1,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: controller,
        maxLines: lines,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}

class SubscriptionTab extends StatelessWidget {
  const SubscriptionTab({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('plans')
          .where('active', isEqualTo: true)
          .snapshots(),
      builder: (_, snapshot) {
        final plans = snapshot.data?.docs ?? [];

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'الاشتراكات وفودافون كاش',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'بعد التحويل لفودافون كاش أرسل طلب الدفع، ويقوم المدير بالمراجعة والتفعيل يدويًا.',
            ),
            const SizedBox(height: 12),
            if (plans.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('لا توجد خطط اشتراك مفعلة حاليًا.'),
                ),
              ),
            ...plans.map((plan) {
              final data = plan.data();
              return Card(
                child: ListTile(
                  title: Text(data['name'] ?? 'خطة'),
                  subtitle: Text(
                    '${data['price'] ?? ''} جنيه • ${data['days'] ?? 30} يوم',
                  ),
                  trailing: FilledButton(
                    onPressed: () => submitPayment(context, plan.id, data),
                    child: const Text('طلب اشتراك'),
                  ),
                ),
              );
            }),
          ],
        );
      },
    );
  }

  Future<void> submitPayment(
    BuildContext context,
    String planId,
    Map<String, dynamic> plan,
  ) async {
    final reference = TextEditingController();

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('بيانات التحويل'),
          content: TextField(
            controller: reference,
            decoration: const InputDecoration(
              labelText: 'رقم العملية أو ملاحظة التحويل',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () async {
                await FirebaseFirestore.instance
                    .collection('paymentRequests')
                    .add({
                  'userId': FirebaseAuth.instance.currentUser!.uid,
                  'planId': planId,
                  'amount': plan['price'],
                  'method': 'فودافون كاش',
                  'reference': reference.text.trim(),
                  'status': 'قيد المراجعة',
                  'createdAt': FieldValue.serverTimestamp(),
                });

                if (dialogContext.mounted) {
                  Navigator.pop(dialogContext);
                }
              },
              child: const Text('إرسال'),
            ),
          ],
        );
      },
    );

    reference.dispose();
  }
}

class AccountTab extends StatelessWidget {
  final Map<String, dynamic> profile;

  const AccountTab({super.key, required this.profile});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const CircleAvatar(
          radius: 38,
          child: Icon(Icons.person, size: 42),
        ),
        const SizedBox(height: 10),
        Center(
          child: Text(
            profile['name'] ?? 'مستخدم',
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
        ),
        Center(child: Text('الدور: ${profile['role'] ?? 'زائر'}')),
        const SizedBox(height: 20),
        Card(
          child: ListTile(
            leading: const Icon(Icons.phone),
            title: Text(
              profile['phone'] ?? 'لم يتم إضافة رقم هاتف',
            ),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.favorite),
            title: const Text('المفضلة'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const FavoritesPage()),
              );
            },
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('تسجيل الخروج'),
            onTap: () => FirebaseAuth.instance.signOut(),
          ),
        ),
      ],
    );
  }
}

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(title: const Text('المفضلة')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc(uid)
            .collection('favorites')
            .snapshots(),
        builder: (_, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('لا توجد إعلانات محفوظة'));
          }

          return ListView(
            children: snapshot.data!.docs.map((doc) {
              final data = doc.data();
              return ListTile(
                title: Text(data['title'] ?? ''),
                subtitle: Text(
                  '${data['category'] ?? ''} • ${data['price'] ?? ''}',
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => doc.reference.delete(),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('لوحة المدير'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'الإعلانات'),
              Tab(text: 'طلبات الدفع'),
              Tab(text: 'المستخدمون'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            AdminAdsTab(),
            AdminPaymentsTab(),
            AdminUsersTab(),
          ],
        ),
      ),
    );
  }
}

class AdminAdsTab extends StatelessWidget {
  const AdminAdsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('ads').snapshots(),
      builder: (_, snapshot) {
        final ads = snapshot.data?.docs ?? [];
        if (ads.isEmpty) {
          return const Center(child: Text('لا توجد إعلانات'));
        }

        return ListView(
          children: ads.map((doc) {
            final data = doc.data();
            return ListTile(
              title: Text(data['title'] ?? ''),
              subtitle: Text(data['status'] ?? ''),
              trailing: Wrap(
                children: [
                  IconButton(
                    tooltip: 'اعتماد',
                    onPressed: () =>
                        doc.reference.update({'status': 'نشط'}),
                    icon: const Icon(Icons.check),
                  ),
                  IconButton(
                    tooltip: 'إخفاء',
                    onPressed: () =>
                        doc.reference.update({'status': 'مخفي'}),
                    icon: const Icon(Icons.visibility_off),
                  ),
                  IconButton(
                    tooltip: 'حذف',
                    onPressed: () => doc.reference.delete(),
                    icon: const Icon(Icons.delete_outline),
                  ),
                ],
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

class AdminPaymentsTab extends StatelessWidget {
  const AdminPaymentsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('paymentRequests')
          .where('status', isEqualTo: 'قيد المراجعة')
          .snapshots(),
      builder: (_, snapshot) {
        final requests = snapshot.data?.docs ?? [];
        if (requests.isEmpty) {
          return const Center(child: Text('لا توجد طلبات دفع معلقة'));
        }

        return ListView(
          children: requests.map((doc) {
            final data = doc.data();
            return ListTile(
              title: Text('${data['amount'] ?? ''} جنيه'),
              subtitle: Text(
                '${data['method'] ?? ''} • ${data['reference'] ?? ''}',
              ),
              trailing: FilledButton(
                onPressed: () => doc.reference.update({
                  'status': 'معتمد',
                  'reviewedAt': FieldValue.serverTimestamp(),
                }),
                child: const Text('اعتماد'),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

class AdminUsersTab extends StatelessWidget {
  const AdminUsersTab({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').snapshots(),
      builder: (_, snapshot) {
        final users = snapshot.data?.docs ?? [];
        return ListView(
          children: users.map((doc) {
            final data = doc.data();
            return ListTile(
              title: Text(data['name'] ?? 'بدون اسم'),
              subtitle: Text(
                '${data['role'] ?? 'زائر'} • ${data['status'] ?? 'نشط'}',
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
