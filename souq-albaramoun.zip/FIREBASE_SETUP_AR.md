# إعداد Firebase لمشروع سوق البرامون

## ما تم تجهيزه في الكود
- Firebase Core.
- Firebase Authentication.
- تسجيل الدخول وإنشاء الحساب بالبريد الإلكتروني وكلمة المرور.
- Cloud Firestore.
- إنشاء ملف المستخدم تلقائيًا في مجموعة `users`.
- قراءة إعلانات المستخدم من مجموعة `ads`.
- قواعد Firestore أولية للمستخدم والمدير والاشتراكات وطلبات الدفع.

## ربط مشروعك الموجود
معرّف مشروع Firebase:
`souq-el-baramoun`

اسم الحزمة المقترح:
`com.souqelbaramoun.app`

## الخطوات التي يجب تنفيذها في Firebase Console
1. افتح مشروع `souq-el-baramoun`.
2. أضف تطبيق Android باسم الحزمة `com.souqelbaramoun.app`.
3. نزّل `google-services.json`.
4. ضع الملف في:
   `android/app/google-services.json`
5. من Authentication فعّل مزوّد `Email/Password`.
6. أنشئ Cloud Firestore واختر أقرب موقع مناسب.
7. انشر قواعد `firestore/rules.txt`.

## تشغيل Flutter
بعد توفر بيئة Flutter:
`flutter pub get`
ثم:
`flutter run`

ملاحظة: لا نضع مفاتيح سرية لخدمات الإدارة داخل التطبيق.
