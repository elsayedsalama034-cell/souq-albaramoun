package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.PartyNavigationTab
import com.example.ui.PartyViewModel
import com.example.ui.components.AboutPartyDialog
import com.example.ui.components.AddProductDialog
import com.example.ui.components.CartDialog
import com.example.ui.components.InitiativeDetailDialog
import com.example.ui.components.MarketInquiryChatDialog
import com.example.ui.components.MarketDetailDialog
import com.example.ui.components.NewsDetailDialog
import com.example.ui.components.OrdersDialog
import com.example.ui.components.PartyBottomBar
import com.example.ui.components.PartyTopBar
import com.example.ui.screens.CitizenServiceScreen
import com.example.ui.screens.DirectoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InitiativesScreen
import com.example.ui.screens.MarketScreen
import com.example.ui.screens.MembershipScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  private val viewModel: PartyViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
          PartyApp(viewModel = viewModel)
        }
      }
    }
  }
}

@Composable
fun PartyApp(viewModel: PartyViewModel) {
  val context = LocalContext.current
  val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
  val newsList by viewModel.newsList.collectAsStateWithLifecycle()
  val selectedNews by viewModel.selectedNews.collectAsStateWithLifecycle()
  val initiatives by viewModel.initiatives.collectAsStateWithLifecycle()
  val selectedInitiative by viewModel.selectedInitiative.collectAsStateWithLifecycle()
  val deputies by viewModel.deputies.collectAsStateWithLifecycle()
  val offices by viewModel.offices.collectAsStateWithLifecycle()
  val citizenRequests by viewModel.citizenRequests.collectAsStateWithLifecycle()
  val citizenForm by viewModel.citizenForm.collectAsStateWithLifecycle()
  val memberships by viewModel.memberships.collectAsStateWithLifecycle()
  val membershipForm by viewModel.membershipForm.collectAsStateWithLifecycle()
  val deputiesSearch by viewModel.deputiesSearchQuery.collectAsStateWithLifecycle()
  val govFilter by viewModel.selectedGovernorateFilter.collectAsStateWithLifecycle()
  val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

  // Marketplace states
  val marketProducts by viewModel.filteredMarketProducts.collectAsStateWithLifecycle()
  val marketFilter by viewModel.marketFilter.collectAsStateWithLifecycle()
  val selectedMarketProduct by viewModel.selectedMarketProduct.collectAsStateWithLifecycle()
  val showAddProductDialog by viewModel.showAddProductDialog.collectAsStateWithLifecycle()
  val newProductForm by viewModel.newProductForm.collectAsStateWithLifecycle()
  val inquiryProduct by viewModel.inquiryProduct.collectAsStateWithLifecycle()
  val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()

  // Cart & Orders states
  val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
  val marketOrders by viewModel.marketOrders.collectAsStateWithLifecycle()
  val appliedCoupon by viewModel.appliedCoupon.collectAsStateWithLifecycle()
  val showCartDialog by viewModel.showCartDialog.collectAsStateWithLifecycle()
  val showOrdersDialog by viewModel.showOrdersDialog.collectAsStateWithLifecycle()
  val isPlacingOrder by viewModel.isPlacingOrder.collectAsStateWithLifecycle()

  var showAboutDialog by remember { mutableStateOf(false) }
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(toastMessage) {
    toastMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearToast()
    }
  }

  Scaffold(
    topBar = {
      PartyTopBar(
        onHotlineClick = {
          try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
              data = Uri.parse("tel:16543")
            }
            context.startActivity(intent)
          } catch (_: Exception) {}
        },
        onAboutClick = { showAboutDialog = true }
      )
    },
    bottomBar = {
      PartyBottomBar(
        currentTab = currentTab,
        onTabSelected = { viewModel.setTab(it) }
      )
    },
    snackbarHost = { SnackbarHost(snackbarHostState) },
    modifier = Modifier.fillMaxSize()
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (currentTab) {
        PartyNavigationTab.HOME -> {
          HomeScreen(
            newsList = newsList,
            initiatives = initiatives,
            onNewsClick = { viewModel.selectNews(it) },
            onInitiativeClick = { viewModel.selectInitiative(it) },
            onNavigate = { viewModel.setTab(it) }
          )
        }
        PartyNavigationTab.MARKETPLACE -> {
          MarketScreen(
            products = marketProducts,
            filterState = marketFilter,
            cartItems = cartItems,
            categories = viewModel.marketCategories,
            governorates = viewModel.governorates,
            onSearchChange = { viewModel.setMarketSearch(it) },
            onCategoryChange = { viewModel.setMarketCategory(it) },
            onGovernorateChange = { viewModel.setMarketGovernorate(it) },
            onToggleMemberDeals = { viewModel.toggleOnlyMemberDeals() },
            onToggleSaved = { viewModel.toggleOnlySaved() },
            onSortChange = { viewModel.setMarketSort(it) },
            onProductClick = { viewModel.selectMarketProduct(it) },
            onAddToCart = { viewModel.addToCart(it) },
            onToggleSave = { viewModel.toggleProductSave(it) },
            onOpenCart = { viewModel.openCartDialog() },
            onOpenAddProduct = { viewModel.openAddProductDialog() }
          )
        }
        PartyNavigationTab.INITIATIVES -> {
          InitiativesScreen(
            initiatives = initiatives,
            onInitiativeClick = { viewModel.selectInitiative(it) }
          )
        }
        PartyNavigationTab.CITIZEN_SERVICE -> {
          CitizenServiceScreen(
            requests = citizenRequests,
            formState = citizenForm,
            governorates = viewModel.governorates,
            requestTypes = viewModel.requestTypes,
            onNameChange = { viewModel.updateCitizenName(it) },
            onNationalIdChange = { viewModel.updateCitizenNationalId(it) },
            onPhoneChange = { viewModel.updateCitizenPhone(it) },
            onGovernorateChange = { viewModel.updateCitizenGovernorate(it) },
            onRequestTypeChange = { viewModel.updateCitizenRequestType(it) },
            onDescriptionChange = { viewModel.updateCitizenDescription(it) },
            onSubmit = { viewModel.submitCitizenRequest() },
            onDeleteRequest = { viewModel.deleteCitizenRequest(it) }
          )
        }
        PartyNavigationTab.MEMBERSHIP -> {
          MembershipScreen(
            memberships = memberships,
            formState = membershipForm,
            governorates = viewModel.governorates,
            committees = viewModel.committees,
            onFullNameChange = { viewModel.updateMembershipFullName(it) },
            onNationalIdChange = { viewModel.updateMembershipNationalId(it) },
            onPhoneChange = { viewModel.updateMembershipPhone(it) },
            onGovernorateChange = { viewModel.updateMembershipGovernorate(it) },
            onDistrictChange = { viewModel.updateMembershipDistrict(it) },
            onQualificationChange = { viewModel.updateMembershipQualification(it) },
            onCommitteeChange = { viewModel.updateMembershipCommittee(it) },
            onSubmit = { viewModel.submitMembership() }
          )
        }
        PartyNavigationTab.DIRECTORY,
        PartyNavigationTab.DEPUTIES,
        PartyNavigationTab.OFFICES -> {
          DirectoryScreen(
            deputies = deputies,
            offices = offices,
            searchQuery = deputiesSearch,
            selectedGovernorate = govFilter,
            governorates = viewModel.governorates,
            onSearchChange = { viewModel.setDeputiesSearch(it) },
            onGovernorateChange = { viewModel.setGovernorateFilter(it) }
          )
        }
      }
    }
  }

  // Dialogs
  selectedNews?.let { news ->
    NewsDetailDialog(
      news = news,
      onDismiss = { viewModel.selectNews(null) }
    )
  }

  selectedInitiative?.let { initiative ->
    InitiativeDetailDialog(
      initiative = initiative,
      onDismiss = { viewModel.selectInitiative(null) },
      onRegisterClick = {
        viewModel.setTab(PartyNavigationTab.CITIZEN_SERVICE)
      }
    )
  }

  selectedMarketProduct?.let { product ->
    MarketDetailDialog(
      product = product,
      onDismiss = { viewModel.selectMarketProduct(null) },
      onAddToCart = { viewModel.addToCart(it) },
      onToggleSave = { viewModel.toggleProductSave(it) },
      onStartInquiryChat = { viewModel.openInquiryChat(it) }
    )
  }

  inquiryProduct?.let { product ->
    MarketInquiryChatDialog(
      product = product,
      messages = chatMessages,
      onSendMessage = { viewModel.sendChatMessage(it) },
      onDismiss = { viewModel.closeInquiryChat() }
    )
  }

  if (showCartDialog) {
    CartDialog(
      cartItems = cartItems,
      appliedCoupon = appliedCoupon,
      availableCoupons = viewModel.promoCoupons,
      isPlacingOrder = isPlacingOrder,
      onDismiss = { viewModel.closeCartDialog() },
      onUpdateQuantity = { item, qty -> viewModel.updateCartItemQuantity(item, qty) },
      onRemoveItem = { item -> viewModel.removeCartItem(item) },
      onClearCart = { viewModel.clearCart() },
      onApplyCoupon = { code -> viewModel.applyCoupon(code) },
      onRemoveCoupon = { viewModel.removeCoupon() },
      onCheckout = { name, phone, deliveryType, outletOrAddress, itemsCount, totalAmount, totalSaved ->
        viewModel.checkoutOrder(name, phone, deliveryType, outletOrAddress, itemsCount, totalAmount, totalSaved)
      }
    )
  }

  if (showOrdersDialog) {
    OrdersDialog(
      orders = marketOrders,
      onDismiss = { viewModel.closeOrdersDialog() }
    )
  }

  if (showAddProductDialog) {
    AddProductDialog(
      formState = newProductForm,
      categories = viewModel.marketCategories,
      governorates = viewModel.governorates,
      onTitleChange = { viewModel.updateNewProductTitle(it) },
      onCategoryChange = { viewModel.updateNewProductCategory(it) },
      onOriginalPriceChange = { viewModel.updateNewProductOriginalPrice(it) },
      onDiscountedPriceChange = { viewModel.updateNewProductDiscountedPrice(it) },
      onGovernorateChange = { viewModel.updateNewProductGovernorate(it) },
      onLocationChange = { viewModel.updateNewProductLocation(it) },
      onSellerNameChange = { viewModel.updateNewProductSellerName(it) },
      onPhoneChange = { viewModel.updateNewProductPhone(it) },
      onWhatsappChange = { viewModel.updateNewProductWhatsapp(it) },
      onDescriptionChange = { viewModel.updateNewProductDescription(it) },
      onMemberExclusiveChange = { viewModel.updateNewProductMemberExclusive(it) },
      onSubmit = { viewModel.submitNewProduct() },
      onDismiss = { viewModel.closeAddProductDialog() }
    )
  }

  if (showAboutDialog) {
    AboutPartyDialog(onDismiss = { showAboutDialog = false })
  }
}
