package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.CartItemEntity
import com.example.data.model.CitizenRequestEntity
import com.example.data.model.MarketOrderEntity
import com.example.data.model.MarketProductEntity
import com.example.data.model.MembershipApplicationEntity

@Database(
  entities = [
    CitizenRequestEntity::class,
    MembershipApplicationEntity::class,
    MarketProductEntity::class,
    CartItemEntity::class,
    MarketOrderEntity::class
  ],
  version = 3,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun citizenRequestDao(): CitizenRequestDao
  abstract fun membershipDao(): MembershipDao
  abstract fun marketProductDao(): MarketProductDao
  abstract fun cartDao(): CartDao
  abstract fun marketOrderDao(): MarketOrderDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "mostaqbal_watan_db"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
