package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.MembershipApplicationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MembershipDao {
  @Query("SELECT * FROM membership_applications ORDER BY id DESC")
  fun getAllMemberships(): Flow<List<MembershipApplicationEntity>>

  @Query("SELECT * FROM membership_applications WHERE nationalId = :nationalId LIMIT 1")
  suspend fun getMembershipByNationalId(nationalId: String): MembershipApplicationEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMembership(application: MembershipApplicationEntity): Long
}
