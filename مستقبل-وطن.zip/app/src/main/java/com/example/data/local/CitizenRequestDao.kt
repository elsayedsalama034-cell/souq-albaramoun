package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.CitizenRequestEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CitizenRequestDao {
  @Query("SELECT * FROM citizen_requests ORDER BY id DESC")
  fun getAllRequests(): Flow<List<CitizenRequestEntity>>

  @Query("SELECT * FROM citizen_requests WHERE trackingCode = :code LIMIT 1")
  suspend fun getRequestByTrackingCode(code: String): CitizenRequestEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRequest(request: CitizenRequestEntity): Long

  @Query("DELETE FROM citizen_requests WHERE id = :id")
  suspend fun deleteRequestById(id: Long)
}
