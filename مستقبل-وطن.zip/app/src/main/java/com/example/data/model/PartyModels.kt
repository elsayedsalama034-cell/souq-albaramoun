package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

data class NewsItem(
  val id: Int,
  val title: String,
  val category: String,
  val date: String,
  val summary: String,
  val content: String,
  val readingTime: String
)

data class InitiativeItem(
  val id: Int,
  val title: String,
  val category: String,
  val location: String,
  val date: String,
  val description: String,
  val beneficiariesCount: String,
  val iconType: String
)

data class ParliamentMember(
  val id: Int,
  val name: String,
  val chamber: String,
  val governorate: String,
  val constituency: String,
  val role: String,
  val phone: String
)

data class PartyOffice(
  val id: Int,
  val title: String,
  val governorate: String,
  val address: String,
  val hotline: String,
  val secretaryName: String
)

@Entity(tableName = "citizen_requests")
data class CitizenRequestEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val trackingCode: String,
  val citizenName: String,
  val nationalId: String,
  val phoneNumber: String,
  val governorate: String,
  val requestType: String,
  val description: String,
  val dateSubmitted: String,
  val status: String
)

@Entity(tableName = "membership_applications")
data class MembershipApplicationEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val membershipCode: String,
  val fullName: String,
  val nationalId: String,
  val phoneNumber: String,
  val governorate: String,
  val district: String,
  val qualification: String,
  val preferredCommittee: String,
  val submissionDate: String,
  val status: String
)

@Entity(tableName = "market_products")
data class MarketProductEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val title: String,
  val category: String,
  val originalPrice: Double,
  val discountedPrice: Double,
  val discountPercent: Int,
  val governorate: String,
  val locationDetails: String,
  val sellerName: String,
  val sellerType: String,
  val phoneNumber: String,
  val whatsappNumber: String,
  val description: String,
  val isMemberExclusiveDiscount: Boolean = false,
  val memberDiscountExtraPercent: Int = 10,
  val condition: String = "جديد ومغلف",
  val rating: Float = 4.8f,
  val reviewsCount: Int = 120,
  val reviewCount: Int = 120,
  val viewsCount: Int = 340,
  val isSaved: Boolean = false,
  val datePosted: String,
  val imageType: String = "food_basket",
  val isVerifiedSeller: Boolean = true
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val productId: Long,
  val productName: String,
  val category: String,
  val unitPrice: Double,
  val originalPrice: Double,
  val quantity: Int = 1,
  val outletLocation: String,
  val imageType: String = "food_basket"
)

@Entity(tableName = "market_orders")
data class MarketOrderEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val orderNumber: String,
  val customerName: String,
  val phoneNumber: String,
  val deliveryType: String,
  val outletOrAddress: String,
  val itemsCount: Int,
  val totalAmount: Double,
  val totalSaved: Double,
  val appliedCoupon: String? = null,
  val orderDate: String,
  val status: String = "تم تأكيد الحجز"
)

data class MarketPromoCoupon(
  val code: String,
  val description: String,
  val discountAmount: Double,
  val isPercentage: Boolean,
  val minOrderAmount: Double = 0.0
)

enum class MarketSortOption(val titleAr: String) {
  NEWEST("الأحدث أولاً"),
  LOWEST_PRICE("الأقل سعراً"),
  HIGHEST_DISCOUNT("الأعلى تخفيضاً"),
  TOP_RATED("الأعلى تقييماً")
}

data class MarketFilterState(
  val searchQuery: String = "",
  val selectedCategory: String = "الكل",
  val selectedGovernorate: String = "الكل",
  val onlyMemberDeals: Boolean = false,
  val onlySaved: Boolean = false,
  val sortBy: MarketSortOption = MarketSortOption.NEWEST
)

data class MarketChatMessage(
  val id: String,
  val productId: Long,
  val text: String,
  val isFromUser: Boolean,
  val time: String
)
