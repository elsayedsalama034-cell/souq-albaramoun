package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.MarketProductEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MarketProductDao {

  @Query("SELECT * FROM market_products ORDER BY id DESC")
  fun getAllProducts(): Flow<List<MarketProductEntity>>

  @Query("SELECT * FROM market_products WHERE isSaved = 1 ORDER BY id DESC")
  fun getSavedProducts(): Flow<List<MarketProductEntity>>

  @Query("SELECT * FROM market_products WHERE id = :id LIMIT 1")
  suspend fun getProductById(id: Long): MarketProductEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProduct(product: MarketProductEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(products: List<MarketProductEntity>)

  @Query("UPDATE market_products SET isSaved = :isSaved WHERE id = :id")
  suspend fun updateSavedStatus(id: Long, isSaved: Boolean)

  @Query("DELETE FROM market_products WHERE id = :id")
  suspend fun deleteProduct(id: Long)

  @Query("SELECT COUNT(*) FROM market_products")
  suspend fun getCount(): Int
}
