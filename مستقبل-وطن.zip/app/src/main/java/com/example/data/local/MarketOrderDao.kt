package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.MarketOrderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MarketOrderDao {

  @Query("SELECT * FROM market_orders ORDER BY id DESC")
  fun getAllOrders(): Flow<List<MarketOrderEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrder(order: MarketOrderEntity): Long
}
