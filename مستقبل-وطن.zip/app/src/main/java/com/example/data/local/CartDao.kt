package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.CartItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CartDao {

  @Query("SELECT * FROM cart_items ORDER BY id DESC")
  fun getAllCartItems(): Flow<List<CartItemEntity>>

  @Query("SELECT * FROM cart_items WHERE productId = :productId LIMIT 1")
  suspend fun getCartItemByProductId(productId: Long): CartItemEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateCartItem(item: CartItemEntity): Long

  @Query("UPDATE cart_items SET quantity = :quantity WHERE id = :id")
  suspend fun updateQuantity(id: Long, quantity: Int)

  @Delete
  suspend fun deleteCartItem(item: CartItemEntity)

  @Query("DELETE FROM cart_items")
  suspend fun clearCart()
}
