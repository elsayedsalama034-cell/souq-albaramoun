package com.example.data.repository

import com.example.data.local.CartDao
import com.example.data.local.CitizenRequestDao
import com.example.data.local.MarketOrderDao
import com.example.data.local.MarketProductDao
import com.example.data.local.MembershipDao
import com.example.data.model.CartItemEntity
import com.example.data.model.CitizenRequestEntity
import com.example.data.model.InitiativeItem
import com.example.data.model.MarketOrderEntity
import com.example.data.model.MarketProductEntity
import com.example.data.model.MarketPromoCoupon
import com.example.data.model.MembershipApplicationEntity
import com.example.data.model.NewsItem
import com.example.data.model.ParliamentMember
import com.example.data.model.PartyOffice
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class PartyRepository(
  private val citizenRequestDao: CitizenRequestDao,
  private val membershipDao: MembershipDao,
  private val marketProductDao: MarketProductDao,
  private val cartDao: CartDao,
  private val marketOrderDao: MarketOrderDao
) {

  val citizenRequests: Flow<List<CitizenRequestEntity>> = citizenRequestDao.getAllRequests()
  val memberships: Flow<List<MembershipApplicationEntity>> = membershipDao.getAllMemberships()
  val marketProducts: Flow<List<MarketProductEntity>> = marketProductDao.getAllProducts()
  val savedProducts: Flow<List<MarketProductEntity>> = marketProductDao.getSavedProducts()
  val cartItems: Flow<List<CartItemEntity>> = cartDao.getAllCartItems()
  val marketOrders: Flow<List<MarketOrderEntity>> = marketOrderDao.getAllOrders()

  val promoCoupons = listOf(
    MarketPromoCoupon(
      code = "WATAN10",
      description = "خصم 10% إضافي لمبادرة مستقبل وطن",
      discountAmount = 10.0,
      isPercentage = true,
      minOrderAmount = 100.0
    ),
    MarketPromoCoupon(
      code = "KHEIR50",
      description = "خصم نقدي 50 ج.م على كراتين المواد الغذائية",
      discountAmount = 50.0,
      isPercentage = false,
      minOrderAmount = 250.0
    ),
    MarketPromoCoupon(
      code = "MASR2024",
      description = "خصم 15% على مستلزمات المدارس",
      discountAmount = 15.0,
      isPercentage = true,
      minOrderAmount = 200.0
    ),
    MarketPromoCoupon(
      code = "SHABAB20",
      description = "خصم 20% لشباب الخريجين والأسر المنتجة",
      discountAmount = 20.0,
      isPercentage = true,
      minOrderAmount = 150.0
    )
  )

  suspend fun addToCart(product: MarketProductEntity, quantity: Int = 1) {
    val existing = cartDao.getCartItemByProductId(product.id)
    if (existing != null) {
      cartDao.updateQuantity(existing.id, existing.quantity + quantity)
    } else {
      cartDao.insertOrUpdateCartItem(
        CartItemEntity(
          productId = product.id,
          productName = product.title,
          category = product.category,
          unitPrice = product.discountedPrice,
          originalPrice = product.originalPrice,
          quantity = quantity,
          outletLocation = product.locationDetails,
          imageType = product.imageType
        )
      )
    }
  }

  suspend fun updateCartQuantity(cartItem: CartItemEntity, quantity: Int) {
    if (quantity <= 0) {
      cartDao.deleteCartItem(cartItem)
    } else {
      cartDao.updateQuantity(cartItem.id, quantity)
    }
  }

  suspend fun removeCartItem(cartItem: CartItemEntity) {
    cartDao.deleteCartItem(cartItem)
  }

  suspend fun clearCart() {
    cartDao.clearCart()
  }

  suspend fun placeMarketOrder(
    customerName: String,
    phoneNumber: String,
    deliveryType: String,
    outletOrAddress: String,
    itemsCount: Int,
    totalAmount: Double,
    totalSaved: Double,
    appliedCoupon: String?
  ): String {
    val orderNumber = "ORD-MW-" + Random.nextInt(10000, 99999).toString()
    val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar", "EG"))
    val orderDate = dateFormat.format(Date())

    val order = MarketOrderEntity(
      orderNumber = orderNumber,
      customerName = customerName,
      phoneNumber = phoneNumber,
      deliveryType = deliveryType,
      outletOrAddress = outletOrAddress,
      itemsCount = itemsCount,
      totalAmount = totalAmount,
      totalSaved = totalSaved,
      appliedCoupon = appliedCoupon,
      orderDate = orderDate,
      status = "تم تأكيد الحجز"
    )

    marketOrderDao.insertOrder(order)
    cartDao.clearCart()
    return orderNumber
  }

  suspend fun seedMarketProductsIfEmpty() {
    if (marketProductDao.getCount() == 0) {
      marketProductDao.insertAll(getInitialMarketProducts())
    }
  }

  suspend fun toggleSaveProduct(id: Long, isSaved: Boolean) {
    marketProductDao.updateSavedStatus(id, isSaved)
  }

  suspend fun addMarketProduct(
    title: String,
    category: String,
    originalPrice: Double,
    discountedPrice: Double,
    governorate: String,
    locationDetails: String,
    sellerName: String,
    sellerType: String,
    phoneNumber: String,
    whatsappNumber: String,
    description: String,
    isMemberExclusive: Boolean,
    memberExtraPercent: Int,
    condition: String,
    imageType: String
  ): Long {
    val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale("ar", "EG"))
    val currentDate = dateFormat.format(Date())
    val discountPercent = if (originalPrice > 0 && originalPrice > discountedPrice) {
      (((originalPrice - discountedPrice) / originalPrice) * 100).toInt()
    } else 0

    val entity = MarketProductEntity(
      title = title,
      category = category,
      originalPrice = originalPrice,
      discountedPrice = discountedPrice,
      discountPercent = discountPercent,
      governorate = governorate,
      locationDetails = locationDetails,
      sellerName = sellerName,
      sellerType = sellerType,
      phoneNumber = phoneNumber,
      whatsappNumber = whatsappNumber,
      description = description,
      isMemberExclusiveDiscount = isMemberExclusive,
      memberDiscountExtraPercent = memberExtraPercent,
      condition = condition,
      rating = 4.8f,
      reviewsCount = Random.nextInt(45, 230),
      viewsCount = Random.nextInt(150, 950),
      isSaved = false,
      datePosted = currentDate,
      imageType = imageType
    )
    return marketProductDao.insertProduct(entity)
  }

  suspend fun deleteMarketProduct(id: Long) {
    marketProductDao.deleteProduct(id)
  }

  suspend fun submitCitizenRequest(
    name: String,
    nationalId: String,
    phone: String,
    governorate: String,
    type: String,
    description: String
  ): String {
    val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale("ar", "EG"))
    val currentDate = dateFormat.format(Date())
    val trackingCode = "MW-" + Random.nextInt(100000, 999999).toString()

    val entity = CitizenRequestEntity(
      trackingCode = trackingCode,
      citizenName = name,
      nationalId = nationalId,
      phoneNumber = phone,
      governorate = governorate,
      requestType = type,
      description = description,
      dateSubmitted = currentDate,
      status = "قيد المراجعة الفورية"
    )
    citizenRequestDao.insertRequest(entity)
    return trackingCode
  }

  suspend fun submitMembership(
    fullName: String,
    nationalId: String,
    phone: String,
    governorate: String,
    district: String,
    qualification: String,
    preferredCommittee: String
  ): String {
    val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale("ar", "EG"))
    val currentDate = dateFormat.format(Date())
    val membershipCode = "EGY-MW-" + Random.nextInt(10000, 99999)

    val entity = MembershipApplicationEntity(
      membershipCode = membershipCode,
      fullName = fullName,
      nationalId = nationalId,
      phoneNumber = phone,
      governorate = governorate,
      district = district,
      qualification = qualification,
      preferredCommittee = preferredCommittee,
      submissionDate = currentDate,
      status = "طلب معتمد أولياً"
    )
    membershipDao.insertMembership(entity)
    return membershipCode
  }

  suspend fun deleteRequest(id: Long) {
    citizenRequestDao.deleteRequestById(id)
  }

  fun getNewsList(): List<NewsItem> {
    return listOf(
      NewsItem(
        id = 1,
        title = "مستقبل وطن يطلق أكبر قافلة طبية مجانية شاملة في 12 محافظة",
        category = "مبادرات مجتمعية",
        date = "اليوم، 10:30 ص",
        summary = "توفير الكشف والعلاج والعمليات الجراحية المجانية لأكثر من 50 ألف مواطن بالقرى الأكثر احتياجاً.",
        content = "في إطار الدور المجتمعي لحزب مستقبل وطن، أطلقت أمانة الصحة والسكان المركزية بالتنسيق مع أمانات المحافظات، أضخم قافلة طبية تضم أكثر من 80 عيادة متنقلة بمختلف التخصصات من باطنة وجراحة وأطفال ورمد، مع صرف الدواء بالمجان وإجراء التحاليل والأشعة الفورية وتحويل الحالات الحرجة لإجراء العمليات على نفقة الدولة.",
        readingTime = "3 دقائق"
      ),
      NewsItem(
        id = 2,
        title = "افتتاح معارض 'أهلاً بالمدارس' لبيع المستلزمات بتخفيضات تصل إلى 35%",
        category = "خدمات المواطنين",
        date = "أمس، 06:15 م",
        summary = "مستقبل وطن يفتتح أكثر من 180 شادراً بالمراكز والمدن لدعم الأسر وتخفيف الأعباء المعيشية.",
        content = "تزامناً مع الاستعداد للعام الدراسي الجديد، افتتحت أمانات العمل الجماهيري والمشروعات معارض ضخمة لتوفير الزي المدرسي والحقائب والأدوات المكتبية بأسعار الجملة بتخفيضات كبرى، تحت رعاية حزب مستقبل وطن، لتخفيف العبء عن كاهل أولياء الأمور بجميع المحافظات.",
        readingTime = "2 دقيقة"
      ),
      NewsItem(
        id = 3,
        title = "انطلاق التصفيات النهائية لـ 'دوري مستقبل وطن' لكرة القدم للشباب",
        category = "أمانة الشباب",
        date = "منذ يومين",
        summary = "مشاركة أكثر من 40 ألف شاب في النسخة الأكبر على مستوى الجمهورية لاكتشاف المواهب الرياضية.",
        content = "تحت شعار 'الرياضة أسلوب حياة'، تتواصل منافسات دوري مستقبل وطن بمشاركة فرق تمثل كافة القرى والأحياء والمدن، مع رصد جوائز مالية كبرى ودروع تكريمية، وتواجد كشافي الأندية المصرية لدعم وتأهيل المواهب الرياضية الشابة في مصر.",
        readingTime = "4 دقائق"
      ),
      NewsItem(
        id = 4,
        title = "اجتماع الهيئة البرلمانية للحزب لمناقشة التشريعات الداعمة للصناعة والاستثمار",
        category = "النشاط البرلماني",
        date = "منذ 3 أيام",
        summary = "التأكيد على تسريع وتيرة إصدار التراخيص وتسهيل إجراءات الدعم للمصانع والشباب ورواد الأعمال.",
        content = "عقدت الهيئة البرلمانية لحزب مستقبل وطن بمجلسي النواب والشيوخ اجتماعاً تنسيقياً رفيع المستوى لمناقشة حزمة القوانين الاقتصادية الجديدة، الهادفة لتشجيع الإنتاج المحلي وتعميق الصناعة الوطنية وخلق فرص عمل واعدة للشباب بالتعاون مع الحكومة.",
        readingTime = "3 دقائق"
      ),
      NewsItem(
        id = 5,
        title = "أمانة المرأة تدشن مبادرة 'صحتك أمانتك' للتوعية الصحية والكشف المبكر",
        category = "أمانة المرأة",
        date = "منذ 4 أيام",
        summary = "تنظيم ندوات تثقيفية وخدمات فحوصات دورية شاملة للمرأة في المراكز والنجوع.",
        content = "نظمت أمانة المرأة بالحزب سلسلة ندوات وجولات ميدانية للتوعية بالصحة الإنجابية وأهمية الكشف المبكر، إلى جانب ورش تدريبية للمشغولات اليدوية والحرف التراثية لتمكين المرأة اقتصادياً ومعيشياً وتوفير منافذ لتسويق منتجاتهن.",
        readingTime = "2 دقيقة"
      )
    )
  }

  fun getInitiatives(): List<InitiativeItem> {
    return listOf(
      InitiativeItem(
        id = 1,
        title = "قوافل الرعاية الصحية المجانية",
        category = "القطاع الصحي",
        location = "جميع محافظات الجمهورية",
        date = "أسبوعياً كل خميس وجمعة",
        description = "عيادات متنقلة، كشوفات متخصصة، تحاليل، وصرف العلاج مجاناً لخدمة أهالينا في القرى والنجوع.",
        beneficiariesCount = "+1.2 مليون مستفيد",
        iconType = "medical"
      ),
      InitiativeItem(
        id = 2,
        title = "معارض السلع والمنتجات المخفضة",
        category = "الدعم التمويني والغذائي",
        location = "الشوادر والميادين الرئيسية بالمحافظات",
        date = "مستمرة طوال العام",
        description = "توفير السلع الاستراتيجية، اللحوم، الدواجن، والسلع الغذائية بتخفيضات تصل إلى 30% لمواجهة الغلاء.",
        beneficiariesCount = "+3.5 مليون أسرة",
        iconType = "food"
      ),
      InitiativeItem(
        id = 3,
        title = "دوري مستقبل وطن الرياضي",
        category = "الشباب والرياضة",
        location = "مراكز الشباب والملاعب المعتمدة",
        date = "الموسم الصيفي السنوي",
        description = "أكبر دورة رياضية للشباب على مستوى القطر المصري لتنمية الروح الرياضية وصقل المهارات البدنية.",
        beneficiariesCount = "+45,000 لاعب وشاب",
        iconType = "sports"
      ),
      InitiativeItem(
        id = 4,
        title = "فصول محو الأمية وتعليم الكبار",
        category = "التعليم وبناء الإنسان",
        location = "مقرات أمانات الحزب ومراكز التنمية",
        date = "دورات متجددة كل شهرين",
        description = "برامج مجانية متطورة بالتعاون مع الهيئة العامة لتعليم الكبار لمنح شهادات معتمدة لأبناء الوطن.",
        beneficiariesCount = "+80,000 خريج",
        iconType = "education"
      ),
      InitiativeItem(
        id = 5,
        title = "حملة 'شتاء دافئ' لتوزيع الأغطية والمساعدات",
        category = "التكافل الاجتماعي",
        location = "قرى المبادرة الرئاسية 'حياة كريمة'",
        date = "موسم الشتاء",
        description = "توزيع بطاطين ومواد غذائية ومستلزمات تدفئة للأسر الأولى بالرعاية بكافة النجوع والمناطق الحدودية.",
        beneficiariesCount = "+500 ألف أسرة",
        iconType = "aid"
      )
    )
  }

  fun getDeputies(): List<ParliamentMember> {
    return listOf(
      ParliamentMember(
        id = 1,
        name = "النائب أحمد دياب",
        chamber = "مجلس الشيوخ",
        governorate = "الجيزة",
        constituency = "الدائرة الأولى",
        role = "أمين أمانة الشباب المركزية",
        phone = "01000000001"
      ),
      ParliamentMember(
        id = 2,
        name = "النائب حسام الخولي",
        chamber = "مجلس الشيوخ",
        governorate = "القاهرة",
        constituency = "القاهرة الكبرى",
        role = "نائب رئيس الحزب ورئيس الهيئة البرلمانية",
        phone = "01000000002"
      ),
      ParliamentMember(
        id = 3,
        name = "النائب عبد الهادي القصبي",
        chamber = "مجلس النواب",
        governorate = "الغربية",
        constituency = "دائرة طنطا",
        role = "رئيس لجنة التضامن والأسرة بمجلس النواب",
        phone = "01000000003"
      ),
      ParliamentMember(
        id = 4,
        name = "النائب طارق رضوان",
        chamber = "مجلس النواب",
        governorate = "سوهاج",
        constituency = "دائرة دار السلام",
        role = "رئيس لجنة حقوق الإنسان بمجلس النواب",
        phone = "01000000004"
      ),
      ParliamentMember(
        id = 5,
        name = "النائب محمد كمال مرعي",
        chamber = "مجلس النواب",
        governorate = "الدقهلية",
        constituency = "دائرة المنصورة",
        role = "رئيس لجنة المشروعات المتوسطة والصغيرة",
        phone = "01000000005"
      ),
      ParliamentMember(
        id = 6,
        name = "النائبة نورا علي",
        chamber = "مجلس النواب",
        governorate = "الإسكندرية",
        constituency = "دائرة محرم بك",
        role = "رئيسة لجنة السياحة والطيران المدني",
        phone = "01000000006"
      ),
      ParliamentMember(
        id = 7,
        name = "النائب عاطف ناصر",
        chamber = "مجلس النواب",
        governorate = "القليوبية",
        constituency = "دائرة شبرا الخيمة",
        role = "رئيس لجنة الاقتراحات والشكاوى بمجلس النواب",
        phone = "01000000007"
      ),
      ParliamentMember(
        id = 8,
        name = "النائب أحمد إدريس",
        chamber = "مجلس النواب",
        governorate = "الأقصر",
        constituency = "دائرة الأقصر",
        role = "أمين تنظيم المحافظة وعضو لجنة الإسكان",
        phone = "01000000008"
      )
    )
  }

  fun getOffices(): List<PartyOffice> {
    return listOf(
      PartyOffice(
        id = 1,
        title = "المقر الرئيسي للحزب - الأمانة المركزية",
        governorate = "القاهرة",
        address = "16 شارع التسعين الشمالي، التجمع الخامس، القاهرة الجديدة",
        hotline = "16543",
        secretaryName = "الأمانة العامة المركزية"
      ),
      PartyOffice(
        id = 2,
        title = "أمانة محافظة الجيزة",
        governorate = "الجيزة",
        address = "شارع مراد، برج الأطباء، أمام حديقة الحيوان، الجيزة",
        hotline = "02-37600001",
        secretaryName = "النائب عادل ناصر - أمين المحافظة"
      ),
      PartyOffice(
        id = 3,
        title = "أمانة محافظة الإسكندرية",
        governorate = "الإسكندرية",
        address = "طريق الجيش، لوران، بجوار مسرح عبد المنعم جابر",
        hotline = "03-5840002",
        secretaryName = "النائب رزق راغب - أمين المحافظة"
      ),
      PartyOffice(
        id = 4,
        title = "أمانة محافظة الدقهلية",
        governorate = "الدقهلية",
        address = "شارع الجيش، برج الأندلس، أمام ديوان عام المحافظة، المنصورة",
        hotline = "050-2310003",
        secretaryName = "النائب هشام الحصري - أمين المحافظة"
      ),
      PartyOffice(
        id = 5,
        title = "أمانة محافظة أسيوط",
        governorate = "أسيوط",
        address = "شارع الجمهورية، أمام جامعة أسيوط القديمة، حي شرق",
        hotline = "088-2340004",
        secretaryName = "المهندس ياسر عمر - أمين المحافظة"
      ),
      PartyOffice(
        id = 6,
        title = "أمانة محافظة سوهاج",
        governorate = "سوهاج",
        address = "شارع كورنيش النيل الشرقي، بجوار مجلس مدينة سوهاج",
        hotline = "093-2320005",
        secretaryName = "اللواء محمد مصطفى - أمين المحافظة"
      )
    )
  }

  val governoratesList = listOf(
    "القاهرة",
    "الجيزة",
    "الإسكندرية",
    "القليوبية",
    "الدقهلية",
    "الشرقية",
    "المنوفية",
    "الغربية",
    "كفر الشيخ",
    "البحيرة",
    "دمياط",
    "بورسعيد",
    "الإسماعيلية",
    "السويس",
    "شمال سيناء",
    "جنوب سيناء",
    "بني سويف",
    "الفيوم",
    "المنيا",
    "أسيوط",
    "سوهاج",
    "قنا",
    "الأقصر",
    "أسوان",
    "البحر الأحمر",
    "الوادي الجديد",
    "مطروح"
  )

  val committeesList = listOf(
    "أمانة الشباب",
    "أمانة المرأة",
    "أمانة العمل الجماهيري",
    "أمانة المهنيين",
    "أمانة العمال والفلاحين",
    "أمانة التدريب والتثقيف",
    "أمانة ذوي الاحتياجات الخاصة",
    "أمانة المشروعات الصغيرة",
    "أمانة الصحة والسكان",
    "أمانة العلاقات الحكومية"
  )

  val requestTypes = listOf(
    "علاج على نفقة الدولة وقوافل طبية",
    "مساعدات اجتماعية وتكافل وتضامن",
    "شكاوى مرافق ومياه وصرف وكهرباء",
    "رصف طرق وإنارة وإنشاءات خدمية",
    "فرص عمل وتدريب مهني وتشغيل",
    "طلبات دعم المزارعين والأسمدة والري",
    "استفسار أو اقتراح عام للحزب"
  )

  val marketCategories = listOf(
    "الكل",
    "سلع غذائية وتموينية",
    "معارض أهلاً بالمدارس",
    "مشروعات وأسر منتجة",
    "أجهزة وإلكترونيات",
    "عقارات وإسكان شباب",
    "سيارات ومستلزمات",
    "فرص عمل وخدمات"
  )

  private fun getInitialMarketProducts(): List<MarketProductEntity> {
    return listOf(
      MarketProductEntity(
        id = 1,
        title = "كرتونة سلع تموينية أساسية مدعمة (زيت، سكر، أرز، مكرونة، شاي)",
        category = "سلع غذائية وتموينية",
        originalPrice = 380.0,
        discountedPrice = 220.0,
        discountPercent = 42,
        governorate = "القاهرة",
        locationDetails = "ميدان رمسيس - شادر مبادرة مكافحة الغلاء",
        sellerName = "أمانة المشروعات والعمل الجماهيري",
        sellerType = "منفذ حزبي رسمي",
        phoneNumber = "16543",
        whatsappNumber = "201016543000",
        description = "توفير السلع الغذائية الأساسية عالية الجودة بأسعار مخفضة بنسبة تتجاوز 40%، تشمل 2 كجم أرز فاخر، 2 لتر زيت خليط، 2 كجم سكر أبيض نقي، 3 أكياس مكرونة، وباكو شاي.",
        isMemberExclusiveDiscount = true,
        memberDiscountExtraPercent = 10,
        condition = "فرز أول ومعبأ حديثاً",
        rating = 4.9f,
        reviewsCount = 384,
        viewsCount = 2150,
        isSaved = false,
        datePosted = "اليوم",
        imageType = "food_basket"
      ),
      MarketProductEntity(
        id = 2,
        title = "شنطة مستلزمات مدرسية متكاملة + زي مدرسي كامل بأسعار المصنع",
        category = "معارض أهلاً بالمدارس",
        originalPrice = 650.0,
        discountedPrice = 385.0,
        discountPercent = 41,
        governorate = "الجيزة",
        locationDetails = "ميدان الجيزة بجوار محطة الجامعة",
        sellerName = "معرض أهلاً بالمدارس - مستقبل وطن",
        sellerType = "منفذ حزبي رسمي",
        phoneNumber = "01099238471",
        whatsappNumber = "201099238471",
        description = "حقيبة مدرسية متينة مبطنة تشمل دستة كراريس وكشاكيل 60 و80 ورقة، طقم أقلام، مساطر وألوان، ولانش بوكس ومقلمة، إضافة لقسيمة استلام زي مدرسي بسعر المصنع مباشرة.",
        isMemberExclusiveDiscount = true,
        memberDiscountExtraPercent = 15,
        condition = "جديد ومغلف",
        rating = 4.8f,
        reviewsCount = 219,
        viewsCount = 1840,
        isSaved = false,
        datePosted = "أمس",
        imageType = "school_supplies"
      ),
      MarketProductEntity(
        id = 3,
        title = "كليم صوف وسجاد يدوي فاخر - إنتاج مشروعات تمكين المرأة المعيلة",
        category = "مشروعات وأسر منتجة",
        originalPrice = 1250.0,
        discountedPrice = 780.0,
        discountPercent = 38,
        governorate = "الشرقية",
        locationDetails = "الزقازيق - معرض الأسر المنتجة بأمانة الحزب",
        sellerName = "أمانة المرأة والمشغولات التراثية",
        sellerType = "مشروع أسر منتجة",
        phoneNumber = "01128374651",
        whatsappNumber = "201128374651",
        description = "سجاد يدوي صوف طبيعي 100% بنقوش مصرية أصيلة، تم نسجه بأيدي سيدات معيلات تلقين التدريب الحرفي ضمن مبادرة التمكين الاقتصادي بالحزب، الشراء يدعم الأسر مباشرة.",
        isMemberExclusiveDiscount = false,
        memberDiscountExtraPercent = 0,
        condition = "صناعة يدوية وتراثية",
        rating = 4.9f,
        reviewsCount = 142,
        viewsCount = 920,
        isSaved = false,
        datePosted = "منذ يومين",
        imageType = "handicrafts"
      ),
      MarketProductEntity(
        id = 4,
        title = "لحوم بلدية طازجة بسعر المزرعة (مبادرة اللحوم المخفضة)",
        category = "سلع غذائية وتموينية",
        originalPrice = 420.0,
        discountedPrice = 295.0,
        discountPercent = 30,
        governorate = "القليوبية",
        locationDetails = "بنها - شادر الموقف العام الجديد",
        sellerName = "منافذ أمانة الفلاحين والإنتاج الحيواني",
        sellerType = "منفذ حزبي رسمي",
        phoneNumber = "01034829104",
        whatsappNumber = "201034829104",
        description = "لحوم كندوز بلدية طازجة ذبح السلخانة اليومي تحت إشراف كامل لمديرية الطب البيطري، توزع يومياً صباحاً بالمنافذ الثابتة والمتحركة بأسعار التكلفة الحقيقية.",
        isMemberExclusiveDiscount = true,
        memberDiscountExtraPercent = 5,
        condition = "طازج يومياً بالختم الرسمي",
        rating = 4.7f,
        reviewsCount = 490,
        viewsCount = 3100,
        isSaved = false,
        datePosted = "اليوم",
        imageType = "meat_poultry"
      ),
      MarketProductEntity(
        id = 5,
        title = "شاشة سمارت 43 بوصة Full HD بنظام أندرويد وضمان 3 سنوات",
        category = "أجهزة وإلكترونيات",
        originalPrice = 11800.0,
        discountedPrice = 8400.0,
        discountPercent = 29,
        governorate = "الإسكندرية",
        locationDetails = "سموحة - معرض تجهيز العرائس والشباب",
        sellerName = "معرض أمانة الشباب للسلع المعمرة",
        sellerType = "تاجر معتمد",
        phoneNumber = "01283749102",
        whatsappNumber = "201283749102",
        description = "ضمن مبادرة تيسير الزواج وتجهيز الشباب، شاشة ذكية متطورة مع ريسيفر داخلي وواي فاي وتطبيقات البث مع إمكانية التقسيط بدون فوائد لحاملي بطاقة العضوية.",
        isMemberExclusiveDiscount = true,
        memberDiscountExtraPercent = 5,
        condition = "جديد بالكرتونة والضمان",
        rating = 4.8f,
        reviewsCount = 98,
        viewsCount = 1450,
        isSaved = false,
        datePosted = "منذ 3 أيام",
        imageType = "appliances"
      ),
      MarketProductEntity(
        id = 6,
        title = "مفروشات قطنية مطرزة وملابس قطن مصري 100%",
        category = "مشروعات وأسر منتجة",
        originalPrice = 890.0,
        discountedPrice = 490.0,
        discountPercent = 45,
        governorate = "الدقهلية",
        locationDetails = "المنصورة - شارع الجيش أمام حديقة الطفل",
        sellerName = "مشغل أمانة المشروعات الصغيرة",
        sellerType = "مشروع أسر منتجة",
        phoneNumber = "01048291039",
        whatsappNumber = "201048291039",
        description = "طقم ملايات قطن مصري فاخر 5 قطع تطريز كمبيوتر ويدوي راقي، متوفر بألوان زاهية وتصميمات عصرية من إنتاج ورش الحرفيين المعتمدين.",
        isMemberExclusiveDiscount = false,
        memberDiscountExtraPercent = 0,
        condition = "جديد فرز أول",
        rating = 4.9f,
        reviewsCount = 76,
        viewsCount = 830,
        isSaved = false,
        datePosted = "منذ 4 أيام",
        imageType = "clothing"
      ),
      MarketProductEntity(
        id = 7,
        title = "وحدات سكنية بنظام التمويل العقاري والتقسيط حتى 20 سنة",
        category = "عقارات وإسكان شباب",
        originalPrice = 490000.0,
        discountedPrice = 410000.0,
        discountPercent = 16,
        governorate = "القاهرة",
        locationDetails = "بدر والعاشر من رمضان - مجمع الإسكان التعاوني",
        sellerName = "لجنة الإسكان التعاوني وتنسيقية الشباب",
        sellerType = "منفذ حزبي رسمي",
        phoneNumber = "16543",
        whatsappNumber = "201016543000",
        description = "شقق سكنية مساحات 90م تشطيب سوبر لوكس كامل المرافق ضمن مبادرة توفير المسكن اللائق للشباب والأسر الجديدة بأقساط ميسرة ودعم مباشر للمستحقين.",
        isMemberExclusiveDiscount = true,
        memberDiscountExtraPercent = 10,
        condition = "تشطيب كامل - جاهز للتسليم",
        rating = 4.9f,
        reviewsCount = 184,
        viewsCount = 4200,
        isSaved = false,
        datePosted = "منذ 5 أيام",
        imageType = "apartment"
      ),
      MarketProductEntity(
        id = 8,
        title = "دورة تدريب وتأهيل مهني في صيانة السيارات والأنظمة الحديثة + تشغيل",
        category = "فرص عمل وخدمات",
        originalPrice = 2500.0,
        discountedPrice = 0.0,
        discountPercent = 100,
        governorate = "القاهرة",
        locationDetails = "مدينة نصر - مركز التدريب التكنولوجي",
        sellerName = "أمانة التدريب والتثقيف وتأهيل الكوادر",
        sellerType = "منفذ حزبي رسمي",
        phoneNumber = "01192847163",
        whatsappNumber = "201192847163",
        description = "منحة مجانية شاملة 100% لشباب الخريجين والفنيين للتدريب على أحدث تقنيات الفحص الإلكتروني والصيانة الميكانيكية مع توفير فرصة عمل فورية في المراكز الشريكة.",
        isMemberExclusiveDiscount = false,
        memberDiscountExtraPercent = 0,
        condition = "شهادة معتمدة + فرصة تشغيل",
        rating = 5.0f,
        reviewsCount = 312,
        viewsCount = 3800,
        isSaved = false,
        datePosted = "منذ أسبوع",
        imageType = "car_parts"
      )
    )
  }
}
