package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MarketOrderEntity
import com.example.ui.theme.LightSkyBorder
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary
import com.example.ui.theme.PhosphorGreenDark
import com.example.ui.theme.PhosphorGreenLight
import com.example.ui.theme.TextPrimaryDark

@Composable
fun OrdersDialog(
  orders: List<MarketOrderEntity>,
  onDismiss: () -> Unit
) {
  val clipboard = LocalClipboardManager.current

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .heightIn(max = 640.dp)
        .clip(RoundedCornerShape(24.dp)),
      color = Color.White,
      border = androidx.compose.foundation.BorderStroke(1.5.dp, LightSkyBorder),
      tonalElevation = 8.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(PhosphorGreenLight),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.ReceiptLong,
                contentDescription = "سجل الطلبات",
                tint = PhosphorGreenDark
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "سجل طلباتي وحجوزاتي",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimaryDark
                )
              )
              Text(
                text = "${orders.size} طلب مسجل",
                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
              )
            }
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "إغلاق",
              tint = Color.Gray
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (orders.isEmpty()) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.ReceiptLong,
              contentDescription = null,
              modifier = Modifier.size(72.dp),
              tint = Color.LightGray
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = "لا توجد طلبات سابقة حتى الآن",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = PartyNavyDark
              )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "عند قيامك بحجز أي سلع من معارض ومنافذ الحزب ستظهر هنا لمتابعة حالتها",
              style = MaterialTheme.typography.bodySmall.copy(
                color = Color.Gray,
                textAlign = TextAlign.Center
              ),
              modifier = Modifier.padding(horizontal = 24.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
              onClick = onDismiss,
              colors = ButtonDefaults.buttonColors(containerColor = PartyNavyDark),
              shape = RoundedCornerShape(12.dp)
            ) {
              Text("العودة للتسوق")
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(orders) { order ->
              Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFC)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(
                        text = order.orderNumber,
                        style = MaterialTheme.typography.bodyMedium.copy(
                          fontWeight = FontWeight.Bold,
                          color = PartyNavyDark
                        )
                      )
                      IconButton(
                        onClick = { clipboard.setText(AnnotatedString(order.orderNumber)) },
                        modifier = Modifier.size(24.dp)
                      ) {
                        Icon(
                          imageVector = Icons.Default.ContentCopy,
                          contentDescription = "نسخ رقم الطلب",
                          modifier = Modifier.size(14.dp),
                          tint = Color.Gray
                        )
                      }
                    }

                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE8F5E9))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                          imageVector = Icons.Default.CheckCircle,
                          contentDescription = null,
                          tint = Color(0xFF2E7D32),
                          modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                          text = order.status,
                          fontSize = 11.sp,
                          color = Color(0xFF2E7D32),
                          fontWeight = FontWeight.Bold
                        )
                      }
                    }
                  }

                  Spacer(modifier = Modifier.height(8.dp))
                  Text(
                    text = "التاريخ: ${order.orderDate}",
                    fontSize = 11.sp,
                    color = Color.Gray
                  )
                  Text(
                    text = "المستلم: ${order.customerName} (${order.phoneNumber})",
                    fontSize = 12.sp,
                    color = PartyNavyDark
                  )
                  Text(
                    text = "${order.deliveryType} - ${order.outletOrAddress}",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                  )

                  Spacer(modifier = Modifier.height(8.dp))
                  Divider(color = Color(0xFFE5E7EB))
                  Spacer(modifier = Modifier.height(8.dp))

                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column {
                      Text(
                        text = "عدد السلع: ${order.itemsCount}",
                        fontSize = 11.sp,
                        color = Color.Gray
                      )
                      if (order.totalSaved > 0) {
                        Text(
                          text = "وفرت: ${order.totalSaved.toInt()} ج.م",
                          fontSize = 11.sp,
                          fontWeight = FontWeight.Bold,
                          color = Color(0xFF2E7D32)
                        )
                      }
                    }

                    Text(
                      text = "${order.totalAmount.toInt()} ج.م",
                      style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = PartyNavyDark
                      )
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
