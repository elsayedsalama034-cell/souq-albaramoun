package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// Mostaqbal Watan Portal Color System
// Very Light Blue (أزرق خفيف جداً) & Phosphorescent Green (أخضر فسفوري)
// ==========================================

// 1. Very Light Blue Palette (أزرق خفيف جداً)
val LightSkyBackground = Color(0xFFF0F7FF)        // Ultra light airy pastel sky blue
val LightSkySurface = Color(0xFFFFFFFF)           // Pure luminous white surface
val LightSkySurfaceVariant = Color(0xFFE0F2FE)    // Very soft ice-blue container
val LightSkyBorder = Color(0xFFBAE6FD)            // Soft light blue border
val LightSkyHeader = Color(0xFFE0F2FE)            // Light blue header background
val LightSkyPrimary = Color(0xFF0284C7)           // Fresh vibrant sky blue
val LightSkyDark = Color(0xFF0369A1)              // Legible deep sky blue

// 2. Phosphorescent Green Palette (أخضر فسفوري)
val PhosphorGreen = Color(0xFF00E676)             // Glowing electric phosphorescent / neon green
val PhosphorGreenGlow = Color(0xFF00FF87)         // Bright neon highlight
val PhosphorGreenDark = Color(0xFF00A854)         // High-contrast emerald-phosphor for text/icons
val PhosphorGreenLight = Color(0xFFDCFCE7)        // Soft glowing phosphor tint for chips/badges
val PhosphorGreenContainer = Color(0xFFE8FDF0)    // Very soft phosphor tint
val PhosphorGreenButtonText = Color(0xFF062E48)   // High-contrast deep navy text on neon green

// 3. High-Contrast Typography
val TextPrimaryDark = Color(0xFF0C3352)           // Deep navy slate for sharp readability
val TextSecondaryDark = Color(0xFF335574)         // Medium slate blue
val TextMuted = Color(0xFF6487A5)                 // Muted slate blue

// 4. Compatibility Mappings with Existing Design Tokens
val PartyNavyPrimary = LightSkyPrimary            // 0xFF0284C7 (Fresh sky blue)
val PartyNavyDark = TextPrimaryDark               // 0xFF0C3352 (Crisp deep navy for titles & high contrast)
val PartyBlueVariant = Color(0xFF38BDF8)          // Light bright cyan
val PartyBlueLight = LightSkySurfaceVariant       // 0xFFE0F2FE (Very light sky blue)

// Brand gold is replaced with vibrant Phosphorescent Green as requested!
val PartyGoldAccent = PhosphorGreen               // 0xFF00E676 (Electric phosphorescent green)
val PartyGoldDark = PhosphorGreenDark             // 0xFF00A854 (Crisp green)
val PartyGoldLight = PhosphorGreenLight           // 0xFFDCFCE7 (Light phosphor tint)

val PartyCyan = Color(0xFF00E5FF)
val PartySuccess = PhosphorGreenDark
val PartySuccessLight = PhosphorGreenLight

val SlateBackground = LightSkyBackground          // #F0F7FF
val SlateSurface = LightSkySurface                // #FFFFFF
val SlateSurfaceVariant = LightSkySurfaceVariant  // #E0F2FE
val SlateBorder = LightSkyBorder                  // #BAE6FD

// Dark Theme Palette (adjusted to keep light cyan and neon phosphor accents)
val DarkBackground = Color(0xFF081B2B)
val DarkSurface = Color(0xFF0E2A42)
val DarkSurfaceVariant = Color(0xFF163C5D)
val DarkPrimary = Color(0xFF38BDF8)
val DarkGold = PhosphorGreen
val DarkTextPrimary = Color(0xFFF0F9FF)
val DarkTextSecondary = Color(0xFF93C5FD)

