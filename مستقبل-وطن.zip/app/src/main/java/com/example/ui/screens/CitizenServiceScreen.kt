package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CitizenRequestEntity
import com.example.ui.CitizenFormState
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyGoldDark
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary
import com.example.ui.theme.PartySuccess
import com.example.ui.theme.PartySuccessLight
import com.example.ui.theme.TextSecondaryDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CitizenServiceScreen(
  requests: List<CitizenRequestEntity>,
  formState: CitizenFormState,
  governorates: List<String>,
  requestTypes: List<String>,
  onNameChange: (String) -> Unit,
  onNationalIdChange: (String) -> Unit,
  onPhoneChange: (String) -> Unit,
  onGovernorateChange: (String) -> Unit,
  onRequestTypeChange: (String) -> Unit,
  onDescriptionChange: (String) -> Unit,
  onSubmit: () -> Unit,
  onDeleteRequest: (Long) -> Unit
) {
  var selectedSubTab by remember { mutableStateOf(0) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .testTag("citizen_service_screen")
  ) {
    // Top Info
    Surface(
      color = PartyNavyDark,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 14.dp)
      ) {
        Text(
          text = "أمانة خدمة المواطنين وتلقي الشكاوى",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "نستقبل طلباتكم والشكاوى لمتابعتها مباشرة مع الهيئة البرلمانية والجهات التنفيذية المعنية",
          style = MaterialTheme.typography.bodySmall.copy(
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 12.sp
          )
        )
      }
    }

    // Tabs
    TabRow(
      selectedTabIndex = selectedSubTab,
      containerColor = MaterialTheme.colorScheme.surface,
      contentColor = PartyNavyPrimary,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          Modifier.tabIndicatorOffset(tabPositions[selectedSubTab]),
          color = PartyNavyPrimary,
          height = 3.dp
        )
      }
    ) {
      Tab(
        selected = selectedSubTab == 0,
        onClick = { selectedSubTab = 0 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("تقديم طلب جديد", fontWeight = if (selectedSubTab == 0) FontWeight.Bold else FontWeight.Normal)
          }
        }
      )
      Tab(
        selected = selectedSubTab == 1,
        onClick = { selectedSubTab = 1 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("سجل طلباتي (${requests.size})", fontWeight = if (selectedSubTab == 1) FontWeight.Bold else FontWeight.Normal)
          }
        }
      )
    }

    if (selectedSubTab == 0) {
      // Form
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // Success banner if submitted
        if (formState.lastSubmittedCode != null) {
          item {
            Card(
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = PartySuccessLight)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = PartySuccess,
                  modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text(
                    text = "تم استلام وتسجيل طلبك بنجاح!",
                    style = MaterialTheme.typography.titleSmall.copy(
                      fontWeight = FontWeight.Bold,
                      color = PartySuccess
                    )
                  )
                  Text(
                    text = "كود المتابعة: ${formState.lastSubmittedCode}",
                    style = MaterialTheme.typography.bodySmall.copy(
                      fontWeight = FontWeight.Bold,
                      color = PartyNavyDark
                    )
                  )
                  Text(
                    text = "يمكنك مراجعة حالة الطلب من تبويب 'سجل طلباتي'",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
                  )
                }
              }
            }
          }
        }

        // Error message
        if (formState.errorMessage != null) {
          item {
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.ErrorOutline,
                  contentDescription = null,
                  tint = Color(0xFFC62828),
                  modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = formState.errorMessage,
                  color = Color(0xFFC62828),
                  style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                )
              }
            }
          }
        }

        // Input Fields
        item {
          OutlinedTextField(
            value = formState.citizenName,
            onValueChange = onNameChange,
            label = { Text("الاسم بالكامل (ثلاثي على الأقل) *") },
            placeholder = { Text("مثال: محمد أحمد علي") },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("citizen_name_input"),
            shape = RoundedCornerShape(12.dp)
          )
        }

        item {
          OutlinedTextField(
            value = formState.nationalId,
            onValueChange = onNationalIdChange,
            label = { Text("الرقم القومي (14 رقماً) *") },
            placeholder = { Text("مثال: 29501010101234") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            supportingText = { Text("${formState.nationalId.length} / 14 رقماً") },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("citizen_national_id_input"),
            shape = RoundedCornerShape(12.dp)
          )
        }

        item {
          OutlinedTextField(
            value = formState.phoneNumber,
            onValueChange = onPhoneChange,
            label = { Text("رقم الهاتف المحمول للتواصل *") },
            placeholder = { Text("مثال: 01012345678") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            supportingText = { Text("${formState.phoneNumber.length} / 11 رقماً") },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("citizen_phone_input"),
            shape = RoundedCornerShape(12.dp)
          )
        }

        // Governorate Dropdown
        item {
          var expandedGov by remember { mutableStateOf(false) }
          ExposedDropdownMenuBox(
            expanded = expandedGov,
            onExpandedChange = { expandedGov = !expandedGov },
            modifier = Modifier.fillMaxWidth()
          ) {
            OutlinedTextField(
              value = formState.governorate,
              onValueChange = {},
              readOnly = true,
              label = { Text("المحافظة *") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedGov) },
              modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            )
            ExposedDropdownMenu(
              expanded = expandedGov,
              onDismissRequest = { expandedGov = false }
            ) {
              governorates.forEach { gov ->
                DropdownMenuItem(
                  text = { Text(gov) },
                  onClick = {
                    onGovernorateChange(gov)
                    expandedGov = false
                  }
                )
              }
            }
          }
        }

        // Request Type Dropdown
        item {
          var expandedType by remember { mutableStateOf(false) }
          ExposedDropdownMenuBox(
            expanded = expandedType,
            onExpandedChange = { expandedType = !expandedType },
            modifier = Modifier.fillMaxWidth()
          ) {
            OutlinedTextField(
              value = formState.requestType,
              onValueChange = {},
              readOnly = true,
              label = { Text("نوع الطلب أو الشكوى *") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedType) },
              modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            )
            ExposedDropdownMenu(
              expanded = expandedType,
              onDismissRequest = { expandedType = false }
            ) {
              requestTypes.forEach { type ->
                DropdownMenuItem(
                  text = { Text(type) },
                  onClick = {
                    onRequestTypeChange(type)
                    expandedType = false
                  }
                )
              }
            }
          }
        }

        // Description
        item {
          OutlinedTextField(
            value = formState.description,
            onValueChange = onDescriptionChange,
            label = { Text("تفاصيل الشكوى أو الطلب *") },
            placeholder = { Text("يرجى شرح الموقف أو الحالة والمنطقة بالتفصيل لتسريع المتابعة...") },
            minLines = 4,
            maxLines = 6,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("citizen_desc_input"),
            shape = RoundedCornerShape(12.dp)
          )
        }

        // Submit button
        item {
          Button(
            onClick = onSubmit,
            enabled = !formState.isSubmitting,
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("submit_citizen_request_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PartyNavyPrimary)
          ) {
            if (formState.isSubmitting) {
              CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp))
            } else {
              Text(
                text = "تسجيل وإرسال الطلب للأمانة",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  fontSize = 15.sp
                )
              )
            }
          }
        }
      }
    } else {
      // Request History List
      if (requests.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              Icons.Default.AssignmentTurnedIn,
              contentDescription = null,
              tint = TextSecondaryDark,
              modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = "لا توجد طلبات مسجلة حالياً",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "قم بتقديم طلب أو شكوى من التبويب السابق وستظهر هنا مع كود المتابعة وحالتها لحظياً",
              style = MaterialTheme.typography.bodySmall.copy(color = TextSecondaryDark),
              modifier = Modifier.padding(horizontal = 20.dp)
            )
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          item {
            Text(
              text = "الطلبات المحفوظة على جهازك: ${requests.size}",
              style = MaterialTheme.typography.labelMedium.copy(color = TextSecondaryDark)
            )
          }

          items(requests, key = { it.id }) { item ->
            CitizenRequestCard(
              request = item,
              onDelete = { onDeleteRequest(item.id) }
            )
          }
        }
      }
    }
  }
}

@Composable
private fun CitizenRequestCard(
  request: CitizenRequestEntity,
  onDelete: () -> Unit
) {
  ElevatedCard(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          color = PartyGoldAccent.copy(alpha = 0.2f),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(
            text = "رقم: ${request.trackingCode}",
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = FontWeight.Bold,
              color = PartyGoldDark
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            color = PartySuccessLight,
            shape = RoundedCornerShape(8.dp)
          ) {
            Text(
              text = request.status,
              style = MaterialTheme.typography.labelSmall.copy(
                color = PartySuccess,
                fontWeight = FontWeight.Bold
              ),
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
            Icon(
              Icons.Default.Delete,
              contentDescription = "حذف الطلب",
              tint = TextSecondaryDark,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = request.requestType,
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = PartyNavyDark
        )
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = request.description,
        style = MaterialTheme.typography.bodyMedium.copy(
          color = MaterialTheme.colorScheme.onSurface,
          fontSize = 13.sp,
          lineHeight = 18.sp
        )
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "مقدم الطلب: ${request.citizenName} (${request.governorate})",
          style = MaterialTheme.typography.bodySmall.copy(color = TextSecondaryDark, fontSize = 11.sp)
        )
        Text(
          text = request.dateSubmitted,
          style = MaterialTheme.typography.bodySmall.copy(color = TextSecondaryDark, fontSize = 11.sp)
        )
      }
    }
  }
}
