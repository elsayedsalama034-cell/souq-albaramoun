package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.InitiativeItem
import com.example.data.model.NewsItem
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyGoldDark
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary
import com.example.ui.theme.TextSecondaryDark

@Composable
fun NewsDetailDialog(
  news: NewsItem,
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            color = PartyNavyPrimary.copy(alpha = 0.1f),
            shape = RoundedCornerShape(8.dp)
          ) {
            Text(
              text = news.category,
              color = PartyNavyPrimary,
              style = MaterialTheme.typography.labelMedium,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              fontWeight = FontWeight.Bold
            )
          }
          Spacer(modifier = Modifier.weight(1f))
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = news.title,
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            lineHeight = 26.sp
          )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.AccessTime,
            contentDescription = null,
            tint = TextSecondaryDark,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "${news.date} • قراءة ${news.readingTime}",
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondaryDark)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))
        Divider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = news.content,
          style = MaterialTheme.typography.bodyMedium.copy(
            lineHeight = 24.sp,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurface
          )
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
          onClick = onDismiss,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = PartyNavyDark)
        ) {
          Text("إغلاق الخبر", color = Color.White)
        }
      }
    }
  }
}

@Composable
fun InitiativeDetailDialog(
  initiative: InitiativeItem,
  onDismiss: () -> Unit,
  onRegisterClick: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            color = PartyGoldAccent.copy(alpha = 0.2f),
            shape = RoundedCornerShape(8.dp)
          ) {
            Text(
              text = initiative.category,
              color = PartyGoldDark,
              style = MaterialTheme.typography.labelMedium,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              fontWeight = FontWeight.Bold
            )
          }
          Spacer(modifier = Modifier.weight(1f))
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = initiative.title,
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp
          )
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.LocationOn,
            contentDescription = null,
            tint = PartyNavyPrimary,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = initiative.location,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.Groups,
            contentDescription = null,
            tint = PartyGoldDark,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "المستفيدين: ${initiative.beneficiariesCount}",
            style = MaterialTheme.typography.bodyMedium.copy(
              fontWeight = FontWeight.Bold,
              color = PartyNavyPrimary
            )
          )
        }

        Spacer(modifier = Modifier.height(14.dp))
        Divider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = initiative.description,
          style = MaterialTheme.typography.bodyMedium.copy(
            lineHeight = 24.sp,
            fontSize = 15.sp
          )
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
          onClick = {
            onDismiss()
            onRegisterClick()
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = PartyNavyPrimary)
        ) {
          Text("الاستفادة من المبادرة أو تقديم طلب", color = Color.White)
        }
      }
    }
  }
}

@Composable
fun AboutPartyDialog(
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(Color.White)
        ) {
          Image(
            painter = painterResource(id = R.drawable.ic_party_logo),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth()
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = "عن حزب مستقبل وطن",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
      }
    },
    text = {
      Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text(
          text = "حزب مستقبل وطن هو الحزب السياسي الأكبر في جمهورية مصر العربية، ويحظى بالأغلبية البرلمانية في مجلس النواب ومجلس الشيوخ.",
          style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "• الشعار: كلنا نعمل من أجل مصر 🇪🇬\n• الرؤية: بناء الإنسان المصري، ودعم الاستقرار الوطني، والمشاركة الفعالة في مسيرة التنمية الشاملة والجمهورية الجديدة.\n• الانتشار: أمانات ومقرات في 27 محافظة، وأكثر من 400 مركز وقسم، وشبكة عمل جماهيري واسعة في كافة القرى والنجوع.",
          style = MaterialTheme.typography.bodySmall.copy(
            lineHeight = 20.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = PartyNavyDark)
      ) {
        Text("حسناً", color = Color.White)
      }
    }
  )
}
