package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.InitiativeItem
import com.example.data.model.NewsItem
import com.example.ui.PartyNavigationTab
import com.example.ui.theme.LightSkyBorder
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyGoldDark
import com.example.ui.theme.PartyGoldLight
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary
import com.example.ui.theme.PhosphorGreen
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun HomeScreen(
  newsList: List<NewsItem>,
  initiatives: List<InitiativeItem>,
  onNewsClick: (NewsItem) -> Unit,
  onInitiativeClick: (InitiativeItem) -> Unit,
  onNavigate: (PartyNavigationTab) -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("home_screen_lazy_column"),
    contentPadding = PaddingValues(bottom = 24.dp)
  ) {
    // 1. Hero Header Card
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(210.dp)
      ) {
        Image(
          painter = painterResource(id = R.drawable.bg_hero_banner),
          contentDescription = "بانر حزب مستقبل وطن",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )
        // Gradient overlay for contrast
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  Color(0xFF0284C7).copy(alpha = 0.50f),
                  Color(0xFF0C3352).copy(alpha = 0.90f)
                )
              )
            )
        )

        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
          verticalArrangement = Arrangement.Bottom
        ) {
          Surface(
            color = PhosphorGreen,
            shape = RoundedCornerShape(20.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
              Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = TextPrimaryDark,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "البوابة الرسمية لحزب مستقبل وطن",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimaryDark
                )
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "معاً نبني مستقبل مصر الواعد",
            style = MaterialTheme.typography.headlineSmall.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White,
              fontSize = 22.sp
            )
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "خدمات المواطنين، القوافل الطبية، طلبات الانضمام للعضوية، والتواصل المباشر مع نواب الدوائر",
            style = MaterialTheme.typography.bodySmall.copy(
              color = Color.White.copy(alpha = 0.85f),
              fontSize = 12.sp,
              lineHeight = 16.sp
            ),
            maxLines = 2
          )
        }
      }
    }

    // 2. Stats Section Bar
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        StatBadge(
          title = "27",
          subtitle = "محافظة",
          modifier = Modifier.weight(1f)
        )
        StatBadge(
          title = "+3.5M",
          subtitle = "مستفيد من المبادرات",
          modifier = Modifier.weight(1f)
        )
        StatBadge(
          title = "الأغلبية",
          subtitle = "الكتلة البرلمانية",
          modifier = Modifier.weight(1f)
        )
      }
    }

    // 3. Quick Action Grid
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp)
      ) {
        Text(
          text = "الخدمات والمحاور السريعة",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
          )
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          QuickActionCard(
            title = "سوق المعارض والمنافذ",
            desc = "سلع مدعمة وتخفيضات الأعضاء",
            icon = Icons.Default.ShoppingCart,
            accentColor = Color(0xFFC62828),
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(PartyNavigationTab.MARKETPLACE) }
          )
          QuickActionCard(
            title = "تقديم شكوى أو طلب",
            desc = "متابعة مع النواب والتنفيذيين",
            icon = Icons.Default.Assignment,
            accentColor = PartyNavyPrimary,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(PartyNavigationTab.CITIZEN_SERVICE) }
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          QuickActionCard(
            title = "طلب عضوية الحزب",
            desc = "انضم لأكبر كتلة شبابية ووطنية",
            icon = Icons.Default.CardMembership,
            accentColor = PartyGoldDark,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(PartyNavigationTab.MEMBERSHIP) }
          )
          QuickActionCard(
            title = "المبادرات والقوافل",
            desc = "معارض ومساعدات طبية",
            icon = Icons.Default.VolunteerActivism,
            accentColor = Color(0xFF2E7D32),
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(PartyNavigationTab.INITIATIVES) }
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth()
        ) {
          QuickActionCard(
            title = "دليل النواب والمقرات والأمانات",
            desc = "تواصل مع نائب دائرتك أو أمانة محافظتك",
            icon = Icons.Default.People,
            accentColor = Color(0xFF0288D1),
            modifier = Modifier.fillMaxWidth(),
            onClick = { onNavigate(PartyNavigationTab.DEPUTIES) }
          )
        }
      }
    }

    // 4. Initiatives Spotlight Slider
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 16.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "أحدث المبادرات المجتمعية",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onBackground
            )
          )
          Text(
            text = "عرض الكل",
            style = MaterialTheme.typography.labelMedium.copy(
              color = PartyNavyPrimary,
              fontWeight = FontWeight.Bold
            ),
            modifier = Modifier
              .clickable { onNavigate(PartyNavigationTab.INITIATIVES) }
              .padding(4.dp)
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
          contentPadding = PaddingValues(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(initiatives) { initiative ->
            InitiativeMiniCard(
              initiative = initiative,
              onClick = { onInitiativeClick(initiative) }
            )
          }
        }
      }
    }

    // 5. Official News Section
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 18.dp)
      ) {
        Text(
          text = "الأخبار والبيانات الرسمية للحزب",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
          )
        )
      }
    }

    items(newsList) { news ->
      NewsListItemCard(
        news = news,
        onClick = { onNewsClick(news) },
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)
      )
    }
  }
}

@Composable
private fun StatBadge(
  title: String,
  subtitle: String,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    border = androidx.compose.foundation.BorderStroke(1.dp, LightSkyBorder),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 10.dp, horizontal = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          color = PartyNavyPrimary,
          fontSize = 17.sp
        )
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.labelSmall.copy(
          color = TextSecondaryDark,
          fontSize = 10.sp
        ),
        maxLines = 1
      )
    }
  }
}

@Composable
private fun QuickActionCard(
  title: String,
  desc: String,
  icon: ImageVector,
  accentColor: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, LightSkyBorder),
    modifier = modifier
      .clickable { onClick() }
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(accentColor.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = accentColor,
          modifier = Modifier.size(24.dp)
        )
      }
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleSmall.copy(
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp
        ),
        maxLines = 1
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = desc,
        style = MaterialTheme.typography.bodySmall.copy(
          color = TextSecondaryDark,
          fontSize = 11.sp
        ),
        maxLines = 1
      )
    }
  }
}

@Composable
private fun InitiativeMiniCard(
  initiative: InitiativeItem,
  onClick: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, LightSkyBorder),
    modifier = Modifier
      .width(260.dp)
      .clickable { onClick() }
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Surface(
        color = PartyGoldAccent.copy(alpha = 0.2f),
        shape = RoundedCornerShape(6.dp)
      ) {
        Text(
          text = initiative.category,
          style = MaterialTheme.typography.labelSmall.copy(
            color = PartyGoldDark,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp
          ),
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = initiative.title,
        style = MaterialTheme.typography.titleSmall.copy(
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp
        ),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = initiative.description,
        style = MaterialTheme.typography.bodySmall.copy(
          color = TextSecondaryDark,
          fontSize = 11.sp,
          lineHeight = 16.sp
        ),
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )
      Spacer(modifier = Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = initiative.beneficiariesCount,
          style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = FontWeight.Bold,
            color = PartyNavyPrimary
          )
        )
        Text(
          text = "تفاصيل المبادرة ←",
          style = MaterialTheme.typography.labelSmall.copy(
            color = PartyGoldDark,
            fontWeight = FontWeight.Bold
          )
        )
      }
    }
  }
}

@Composable
fun NewsListItemCard(
  news: NewsItem,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  ElevatedCard(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = modifier
      .fillMaxWidth()
      .clickable { onClick() }
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          color = PartyNavyPrimary.copy(alpha = 0.1f),
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = news.category,
            style = MaterialTheme.typography.labelSmall.copy(
              color = PartyNavyPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp
            ),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
        Text(
          text = news.date,
          style = MaterialTheme.typography.labelSmall.copy(
            color = TextSecondaryDark,
            fontSize = 10.sp
          )
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = news.title,
        style = MaterialTheme.typography.titleSmall.copy(
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp,
          lineHeight = 20.sp
        )
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = news.summary,
        style = MaterialTheme.typography.bodySmall.copy(
          color = TextSecondaryDark,
          fontSize = 12.sp,
          lineHeight = 17.sp
        ),
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(8.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "قراءة الخبر كاملاً",
          style = MaterialTheme.typography.labelSmall.copy(
            color = PartyNavyPrimary,
            fontWeight = FontWeight.Bold
          )
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
          imageVector = Icons.Default.ArrowBack, // In RTL, ArrowBack points forward (left)
          contentDescription = null,
          tint = PartyNavyPrimary,
          modifier = Modifier.size(12.dp)
        )
      }
    }
  }
}
