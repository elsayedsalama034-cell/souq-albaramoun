package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.LightSkyBorder
import com.example.ui.theme.LightSkyHeader
import com.example.ui.theme.LightSkyPrimary
import com.example.ui.theme.PhosphorGreen
import com.example.ui.theme.PhosphorGreenDark
import com.example.ui.theme.PhosphorGreenLight
import com.example.ui.theme.TextPrimaryDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PartyTopBar(
  cartItemsCount: Int = 0,
  onCartClick: () -> Unit = {},
  onOrdersClick: () -> Unit = {},
  onHotlineClick: () -> Unit,
  onAboutClick: () -> Unit
) {
  TopAppBar(
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
      ) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(Color.White)
            .border(2.dp, PhosphorGreen, CircleShape)
            .padding(2.dp),
          contentAlignment = Alignment.Center
        ) {
          Image(
            painter = painterResource(id = R.drawable.ic_party_logo),
            contentDescription = "شعار حزب مستقبل وطن",
            contentScale = ContentScale.Crop,
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "حزب مستقبل وطن",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 17.sp,
              color = TextPrimaryDark
            )
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = PhosphorGreenLight
            ) {
              Text(
                text = "🇪🇬 كلنا نعمل من أجل مصر",
                style = MaterialTheme.typography.labelSmall.copy(
                  color = PhosphorGreenDark,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
              )
            }
          }
        }
      }
    },
    actions = {
      IconButton(
        onClick = onCartClick,
        modifier = Modifier.testTag("cart_top_button")
      ) {
        BadgedBox(
          badge = {
            if (cartItemsCount > 0) {
              Badge(
                containerColor = PhosphorGreen,
                contentColor = TextPrimaryDark
              ) {
                Text("$cartItemsCount", fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        ) {
          Icon(
            imageVector = Icons.Default.ShoppingCart,
            contentDescription = "سلة المشتريات",
            tint = if (cartItemsCount > 0) PhosphorGreenDark else LightSkyPrimary
          )
        }
      }
      IconButton(
        onClick = onOrdersClick,
        modifier = Modifier.testTag("orders_top_button")
      ) {
        Icon(
          imageVector = Icons.Default.ReceiptLong,
          contentDescription = "طلباتي وحجوزاتي",
          tint = LightSkyPrimary
        )
      }
      IconButton(
        onClick = onHotlineClick,
        modifier = Modifier.testTag("hotline_top_button")
      ) {
        Icon(
          imageVector = Icons.Default.Phone,
          contentDescription = "الخط الساخن للحزب 16543",
          tint = PhosphorGreenDark
        )
      }
      IconButton(
        onClick = onAboutClick,
        modifier = Modifier.testTag("about_top_button")
      ) {
        Icon(
          imageVector = Icons.Default.Info,
          contentDescription = "عن الحزب",
          tint = LightSkyPrimary
        )
      }
    },
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = LightSkyHeader,
      titleContentColor = TextPrimaryDark
    )
  )
}
