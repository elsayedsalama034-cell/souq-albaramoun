package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HowToVote
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ParliamentMember
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyGoldDark
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary
import com.example.ui.theme.TextSecondaryDark

@Composable
fun DeputiesScreen(
  deputies: List<ParliamentMember>,
  searchQuery: String,
  selectedGovernorate: String,
  governorates: List<String>,
  onSearchChange: (String) -> Unit,
  onGovernorateChange: (String) -> Unit
) {
  val context = LocalContext.current
  var chamberFilter by remember { mutableStateOf("الكل") }

  val filteredDeputies = deputies.filter { member ->
    val matchesSearch = member.name.contains(searchQuery, ignoreCase = true) ||
      member.constituency.contains(searchQuery, ignoreCase = true) ||
      member.role.contains(searchQuery, ignoreCase = true)

    val matchesGov = selectedGovernorate == "الكل" || member.governorate == selectedGovernorate
    val matchesChamber = chamberFilter == "الكل" || member.chamber == chamberFilter

    matchesSearch && matchesGov && matchesChamber
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .testTag("deputies_screen")
  ) {
    // Header
    Surface(
      color = PartyNavyDark,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 14.dp)
      ) {
        Text(
          text = "الهيئة البرلمانية لحزب مستقبل وطن",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "دليل نواب مجلسي النواب والشيوخ للتواصل وعرض متطلبات الدوائر والمواطنين",
          style = MaterialTheme.typography.bodySmall.copy(
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 12.sp
          )
        )
      }
    }

    // Search bar
    OutlinedTextField(
      value = searchQuery,
      onValueChange = onSearchChange,
      placeholder = { Text("ابحث باسم النائب، الدائرة، أو المنصب...") },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
      singleLine = true,
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp)
        .testTag("deputies_search_input"),
      shape = RoundedCornerShape(12.dp)
    )

    // Chamber filter chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      listOf("الكل", "مجلس النواب", "مجلس الشيوخ").forEach { chamber ->
        val isSelected = chamberFilter == chamber
        FilterChip(
          selected = isSelected,
          onClick = { chamberFilter = chamber },
          label = {
            Text(
              text = chamber,
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            )
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = PartyNavyPrimary,
            selectedLabelColor = Color.White
          )
        )
      }
    }

    // Governorate Filter Chips Row
    LazyRow(
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      item {
        val isSelected = selectedGovernorate == "الكل"
        FilterChip(
          selected = isSelected,
          onClick = { onGovernorateChange("الكل") },
          label = { Text("جميع المحافظات") },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = PartyGoldDark,
            selectedLabelColor = Color.White
          )
        )
      }
      items(governorates) { gov ->
        val isSelected = selectedGovernorate == gov
        FilterChip(
          selected = isSelected,
          onClick = { onGovernorateChange(gov) },
          label = { Text(gov) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = PartyGoldDark,
            selectedLabelColor = Color.White
          )
        )
      }
    }

    // Deputies list
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      item {
        Text(
          text = "إجمالي النواب المطابقين للبحث: ${filteredDeputies.size}",
          style = MaterialTheme.typography.labelMedium.copy(color = TextSecondaryDark)
        )
      }

      items(filteredDeputies, key = { it.id }) { deputy ->
        DeputyCard(
          deputy = deputy,
          onCallClick = {
            val intent = Intent(Intent.ACTION_DIAL).apply {
              data = Uri.parse("tel:${deputy.phone}")
            }
            context.startActivity(intent)
          }
        )
      }
    }
  }
}

@Composable
private fun DeputyCard(
  deputy: ParliamentMember,
  onCallClick: () -> Unit
) {
  ElevatedCard(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(50.dp)
          .clip(CircleShape)
          .background(PartyNavyPrimary.copy(alpha = 0.1f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Person,
          contentDescription = null,
          tint = PartyNavyPrimary,
          modifier = Modifier.size(28.dp)
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            color = if (deputy.chamber == "مجلس النواب") PartyNavyPrimary.copy(alpha = 0.1f) else PartyGoldAccent.copy(alpha = 0.2f),
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = deputy.chamber,
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (deputy.chamber == "مجلس النواب") PartyNavyPrimary else PartyGoldDark,
                fontSize = 10.sp
              ),
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "محافظة ${deputy.governorate}",
            style = MaterialTheme.typography.bodySmall.copy(
              color = TextSecondaryDark,
              fontSize = 11.sp
            )
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = deputy.name,
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
          text = "${deputy.constituency} • ${deputy.role}",
          style = MaterialTheme.typography.bodySmall.copy(
            color = TextSecondaryDark,
            fontSize = 12.sp
          ),
          maxLines = 2
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      IconButton(
        onClick = onCallClick,
        modifier = Modifier
          .clip(CircleShape)
          .background(PartyNavyDark)
      ) {
        Icon(
          Icons.Default.Phone,
          contentDescription = "اتصال بمكتب النائب",
          tint = Color.White,
          modifier = Modifier.size(18.dp)
        )
      }
    }
  }
}
