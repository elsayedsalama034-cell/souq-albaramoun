package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.MembershipApplicationEntity
import com.example.ui.MembershipFormState
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyGoldDark
import com.example.ui.theme.PartyGoldLight
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary
import com.example.ui.theme.PartySuccess
import com.example.ui.theme.PartySuccessLight
import com.example.ui.theme.TextSecondaryDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MembershipScreen(
  memberships: List<MembershipApplicationEntity>,
  formState: MembershipFormState,
  governorates: List<String>,
  committees: List<String>,
  onFullNameChange: (String) -> Unit,
  onNationalIdChange: (String) -> Unit,
  onPhoneChange: (String) -> Unit,
  onGovernorateChange: (String) -> Unit,
  onDistrictChange: (String) -> Unit,
  onQualificationChange: (String) -> Unit,
  onCommitteeChange: (String) -> Unit,
  onSubmit: () -> Unit
) {
  var selectedTab by remember { mutableStateOf(0) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .testTag("membership_screen")
  ) {
    // Header
    Surface(
      color = PartyNavyDark,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 14.dp)
      ) {
        Text(
          text = "استمارة طلب الانضمام والعضوية الحزبية",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "شارك في العمل الحزبي والوطني، وكن جزءاً من مسيرة البناء والتنمية في مصر",
          style = MaterialTheme.typography.bodySmall.copy(
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 12.sp
          )
        )
      }
    }

    // Tabs
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = MaterialTheme.colorScheme.surface,
      contentColor = PartyNavyPrimary,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
          color = PartyNavyPrimary,
          height = 3.dp
        )
      }
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("طلب عضوية جديد", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal)
          }
        }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Badge, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("بطاقة العضوية (${memberships.size})", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal)
          }
        }
      )
    }

    if (selectedTab == 0) {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // Success banner
        if (formState.lastMembershipCode != null) {
          item {
            Card(
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = PartySuccessLight)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = PartySuccess,
                  modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text(
                    text = "تم قبول طلب انضمامك مبدئياً!",
                    style = MaterialTheme.typography.titleSmall.copy(
                      fontWeight = FontWeight.Bold,
                      color = PartySuccess
                    )
                  )
                  Text(
                    text = "كود العضوية: ${formState.lastMembershipCode}",
                    style = MaterialTheme.typography.bodySmall.copy(
                      fontWeight = FontWeight.Bold,
                      color = PartyNavyDark
                    )
                  )
                  Text(
                    text = "يمكنك استعراض بطاقة العضوية الرقمية من التبويب الثاني",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
                  )
                }
              }
            }
          }
        }

        // Error message
        if (formState.errorMessage != null) {
          item {
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.ErrorOutline,
                  contentDescription = null,
                  tint = Color(0xFFC62828),
                  modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = formState.errorMessage,
                  color = Color(0xFFC62828),
                  style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                )
              }
            }
          }
        }

        item {
          OutlinedTextField(
            value = formState.fullName,
            onValueChange = onFullNameChange,
            label = { Text("الاسم الرباعي كما في بطاقة الرقم القومي *") },
            placeholder = { Text("مثال: أحمد محمود علي إبراهيم") },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("membership_name_input"),
            shape = RoundedCornerShape(12.dp)
          )
        }

        item {
          OutlinedTextField(
            value = formState.nationalId,
            onValueChange = onNationalIdChange,
            label = { Text("الرقم القومي (14 رقماً) *") },
            placeholder = { Text("الرقم المكون من 14 خانة") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            supportingText = { Text("${formState.nationalId.length} / 14 رقماً") },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("membership_national_id_input"),
            shape = RoundedCornerShape(12.dp)
          )
        }

        item {
          OutlinedTextField(
            value = formState.phoneNumber,
            onValueChange = onPhoneChange,
            label = { Text("رقم الهاتف المحمول (واتساب) *") },
            placeholder = { Text("01xxxxxxxxx") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            supportingText = { Text("${formState.phoneNumber.length} / 11 رقماً") },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("membership_phone_input"),
            shape = RoundedCornerShape(12.dp)
          )
        }

        // Governorate
        item {
          var expandedGov by remember { mutableStateOf(false) }
          ExposedDropdownMenuBox(
            expanded = expandedGov,
            onExpandedChange = { expandedGov = !expandedGov },
            modifier = Modifier.fillMaxWidth()
          ) {
            OutlinedTextField(
              value = formState.governorate,
              onValueChange = {},
              readOnly = true,
              label = { Text("المحافظة *") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedGov) },
              modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            )
            ExposedDropdownMenu(
              expanded = expandedGov,
              onDismissRequest = { expandedGov = false }
            ) {
              governorates.forEach { gov ->
                DropdownMenuItem(
                  text = { Text(gov) },
                  onClick = {
                    onGovernorateChange(gov)
                    expandedGov = false
                  }
                )
              }
            }
          }
        }

        item {
          OutlinedTextField(
            value = formState.district,
            onValueChange = onDistrictChange,
            label = { Text("المركز / القسم / الحي *") },
            placeholder = { Text("مثال: مركز الزقازيق / قسم الدقي") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
          )
        }

        item {
          OutlinedTextField(
            value = formState.qualification,
            onValueChange = onQualificationChange,
            label = { Text("المؤهل الدراسي / الوظيفة الحالية") },
            placeholder = { Text("مثال: بكالوريوس هندسة / مهندس استشاري") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
          )
        }

        // Committee
        item {
          var expandedComm by remember { mutableStateOf(false) }
          ExposedDropdownMenuBox(
            expanded = expandedComm,
            onExpandedChange = { expandedComm = !expandedComm },
            modifier = Modifier.fillMaxWidth()
          ) {
            OutlinedTextField(
              value = formState.preferredCommittee,
              onValueChange = {},
              readOnly = true,
              label = { Text("الأمانة النوعية الراغب في الانضمام إليها *") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedComm) },
              modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            )
            ExposedDropdownMenu(
              expanded = expandedComm,
              onDismissRequest = { expandedComm = false }
            ) {
              committees.forEach { comm ->
                DropdownMenuItem(
                  text = { Text(comm) },
                  onClick = {
                    onCommitteeChange(comm)
                    expandedComm = false
                  }
                )
              }
            }
          }
        }

        item {
          Button(
            onClick = onSubmit,
            enabled = !formState.isSubmitting,
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("submit_membership_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PartyGoldDark)
          ) {
            if (formState.isSubmitting) {
              CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp))
            } else {
              Text(
                text = "تأكيد طلب الانضمام وإصدار البطاقة",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  fontSize = 15.sp
                )
              )
            }
          }
        }
      }
    } else {
      // Membership Cards
      if (memberships.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              Icons.Default.CardMembership,
              contentDescription = null,
              tint = TextSecondaryDark,
              modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = "لا توجد بطاقات عضوية مصدرة بعد",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "قم بملء استمارة العضوية بالتبويب الأول للحصول فوراً على بطاقتك الحزبية الرقمية",
              style = MaterialTheme.typography.bodySmall.copy(color = TextSecondaryDark),
              modifier = Modifier.padding(horizontal = 20.dp)
            )
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          items(memberships, key = { it.id }) { item ->
            DigitalMembershipCard(application = item)
          }
        }
      }
    }
  }
}

@Composable
private fun DigitalMembershipCard(
  application: MembershipApplicationEntity
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
    modifier = Modifier
      .fillMaxWidth()
      .border(1.5.dp, PartyGoldAccent, RoundedCornerShape(20.dp))
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .background(
          Brush.linearGradient(
            colors = listOf(
              PartyNavyDark,
              Color(0xFF0F3066),
              PartyNavyDark
            )
          )
        )
        .padding(20.dp)
    ) {
      Column {
        // Top Card Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(Color.White)
                .padding(2.dp)
            ) {
              Image(
                painter = painterResource(id = R.drawable.ic_party_logo),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "حزب مستقبل وطن",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              )
              Text(
                text = "بطاقة عضوية رسمية رقمية",
                style = MaterialTheme.typography.labelSmall.copy(
                  color = PartyGoldAccent,
                  fontSize = 10.sp
                )
              )
            }
          }

          Surface(
            color = PartyGoldAccent,
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = "عضو عامل",
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = PartyNavyDark,
                fontSize = 10.sp
              ),
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Name and ID
        Text(
          text = application.fullName,
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 18.sp
          )
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = "الرقم القومي: ${application.nationalId}",
          style = MaterialTheme.typography.bodySmall.copy(
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 12.sp
          )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Governorate & Committee info
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text(
              text = "الأمانة النوعية",
              style = MaterialTheme.typography.labelSmall.copy(
                color = PartyGoldAccent,
                fontSize = 10.sp
              )
            )
            Text(
              text = application.preferredCommittee,
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            )
          }

          Column(horizontalAlignment = Alignment.End) {
            Text(
              text = "أمانة المحافظة",
              style = MaterialTheme.typography.labelSmall.copy(
                color = PartyGoldAccent,
                fontSize = 10.sp
              )
            )
            Text(
              text = "${application.governorate} - ${application.district}",
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bottom Card Info Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "كود: ${application.membershipCode}",
            style = MaterialTheme.typography.labelSmall.copy(
              color = PartyGoldAccent,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            )
          )
          Text(
            text = "تاريخ الإصدار: ${application.submissionDate}",
            style = MaterialTheme.typography.labelSmall.copy(
              color = Color.White.copy(alpha = 0.7f),
              fontSize = 10.sp
            )
          )
        }
      }
    }
  }
}
