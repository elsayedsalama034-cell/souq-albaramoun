package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MarketChatMessage
import com.example.data.model.MarketProductEntity
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary

@Composable
fun MarketInquiryChatDialog(
  product: MarketProductEntity,
  messages: List<MarketChatMessage>,
  onSendMessage: (String) -> Unit,
  onDismiss: () -> Unit
) {
  var inputText by remember { mutableStateOf("") }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .heightIn(max = 620.dp)
        .clip(RoundedCornerShape(24.dp)),
      color = Color.White,
      tonalElevation = 8.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(PartyGoldAccent.copy(alpha = 0.25f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.SupportAgent,
                contentDescription = null,
                tint = PartyNavyDark
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "استفسار فوري عن السلعة",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = PartyNavyDark
                )
              )
              Text(
                text = product.title,
                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray),
                maxLines = 1
              )
            }
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "إغلاق",
              tint = Color.Gray
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Chat message history
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFF8FAFC))
            .padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(messages) { msg ->
            val isMe = msg.isFromUser
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = if (isMe) Arrangement.Start else Arrangement.End
            ) {
              Box(
                modifier = Modifier
                  .clip(
                    RoundedCornerShape(
                      topStart = 14.dp,
                      topEnd = 14.dp,
                      bottomStart = if (isMe) 2.dp else 14.dp,
                      bottomEnd = if (isMe) 14.dp else 2.dp
                    )
                  )
                  .background(if (isMe) PartyNavyDark else Color.White)
                  .padding(horizontal = 12.dp, vertical = 8.dp)
              ) {
                Column {
                  Text(
                    text = msg.text,
                    fontSize = 13.sp,
                    color = if (isMe) Color.White else PartyNavyDark,
                    lineHeight = 18.sp
                  )
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = msg.time,
                    fontSize = 9.sp,
                    color = if (isMe) Color.White.copy(alpha = 0.6f) else Color.Gray,
                    modifier = Modifier.align(Alignment.End)
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quick suggested questions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          val quickQuestions = listOf("السعر والخصم؟", "أين العنوان؟", "مواعيد العمل؟")
          quickQuestions.forEach { q ->
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFFEFF6FF))
                .clickable { onSendMessage(q) }
                .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
              Text(
                text = q,
                fontSize = 11.sp,
                color = PartyNavyPrimary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input row
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = inputText,
            onValueChange = { inputText = it },
            placeholder = { Text("اكتب استفسارك هنا...", fontSize = 12.sp) },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(14.dp),
            singleLine = true
          )
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              if (inputText.isNotBlank()) {
                onSendMessage(inputText)
                inputText = ""
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = PartyNavyDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.height(48.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Send,
              contentDescription = "إرسال",
              tint = Color.White,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }
    }
  }
}
