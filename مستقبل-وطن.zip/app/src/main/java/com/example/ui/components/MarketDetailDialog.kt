package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MarketProductEntity
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary

@Composable
fun MarketDetailDialog(
  product: MarketProductEntity,
  onDismiss: () -> Unit,
  onAddToCart: (MarketProductEntity) -> Unit,
  onToggleSave: (MarketProductEntity) -> Unit,
  onStartInquiryChat: (MarketProductEntity) -> Unit
) {
  val context = LocalContext.current
  val scrollState = rememberScrollState()

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .heightIn(max = 680.dp)
        .clip(RoundedCornerShape(24.dp)),
      color = Color.White,
      tonalElevation = 8.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(scrollState)
          .padding(20.dp)
      ) {
        // Top action bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row {
            IconButton(
              onClick = { onToggleSave(product) },
              modifier = Modifier.size(36.dp)
            ) {
              Icon(
                imageVector = if (product.isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "حفظ",
                tint = if (product.isSaved) Color.Red else Color.Gray
              )
            }
            IconButton(
              onClick = {
                val sendIntent = Intent().apply {
                  action = Intent.ACTION_SEND
                  putExtra(
                    Intent.EXTRA_TEXT,
                    "شاهد هذا العرض من معارض ومنافذ حزب مستقبل وطن:\n${product.title}\nبسعر ${product.discountedPrice.toInt()} ج.م فقط بدلاً من ${product.originalPrice.toInt()} ج.م.\nالموقع: ${product.locationDetails}، ${product.governorate}.\nكلنا نعمل من أجل مصر 🇪🇬"
                  )
                  type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, "مشاركة العرض"))
              },
              modifier = Modifier.size(36.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "مشاركة",
                tint = Color.Gray
              )
            }
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "إغلاق",
              tint = Color.Gray
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Hero Graphic / Category Banner
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(PartyNavyDark),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = Icons.Default.Storefront,
              contentDescription = null,
              tint = PartyGoldAccent,
              modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "معارض ومنافذ حزب مستقبل وطن",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
            Text(
              text = product.category,
              color = PartyGoldAccent,
              fontSize = 12.sp
            )
          }

          // Discount Badge
          Box(
            modifier = Modifier
              .align(Alignment.TopEnd)
              .padding(10.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFE53935))
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = "خصم ${product.discountPercent}%",
              color = Color.White,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Title and Rating
        Text(
          text = product.title,
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            color = PartyNavyDark
          )
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.LocationOn,
              contentDescription = null,
              tint = PartyNavyPrimary,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "${product.governorate} - ${product.locationDetails}",
              fontSize = 12.sp,
              color = Color.Gray
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Star,
              contentDescription = null,
              tint = PartyGoldAccent,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "${product.rating} (${product.reviewCount} تقييم)",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = PartyNavyDark
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Price Card
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "السعر المدعم للمواطنين",
                  fontSize = 11.sp,
                  color = Color.Gray
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "${product.discountedPrice.toInt()} ج.م",
                    style = MaterialTheme.typography.headlineMedium.copy(
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFF2E7D32)
                    )
                  )
                  if (product.originalPrice > product.discountedPrice) {
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                      text = "${product.originalPrice.toInt()} ج.م",
                      style = MaterialTheme.typography.titleMedium.copy(
                        textDecoration = TextDecoration.LineThrough,
                        color = Color.Gray
                      )
                    )
                  }
                }
              }

              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(10.dp))
                  .background(Color(0xFFE8F5E9))
                  .padding(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Text(
                  text = "وفرت ${(product.originalPrice - product.discountedPrice).toInt()} ج.م",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF2E7D32)
                )
              }
            }

            if (product.isMemberExclusiveDiscount) {
              Spacer(modifier = Modifier.height(10.dp))
              Divider(color = Color(0xFFE5E7EB))
              Spacer(modifier = Modifier.height(8.dp))
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Verified,
                  contentDescription = null,
                  tint = PartyGoldAccent,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "خصم إضافي ${product.memberDiscountExtraPercent}% لحاملي كارنيه حزب مستقبل وطن",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = PartyNavyDark
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Description
        Text(
          text = "تفاصيل السلعة والمواصفات",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = PartyNavyDark
          )
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = product.description,
          style = MaterialTheme.typography.bodyMedium.copy(
            color = Color(0xFF374151),
            lineHeight = 22.sp
          )
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Seller & Outlet Card
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(PartyNavyDark),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Storefront,
                contentDescription = null,
                tint = PartyGoldAccent
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = product.sellerName,
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = PartyNavyDark
                )
                if (product.isVerifiedSeller) {
                  Spacer(modifier = Modifier.width(4.dp))
                  Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "معتمد",
                    tint = Color(0xFF0288D1),
                    modifier = Modifier.size(14.dp)
                  )
                }
              }
              Text(
                text = product.sellerType,
                fontSize = 11.sp,
                color = Color.Gray
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Contact buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = {
              val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:${product.phoneNumber}")
              }
              context.startActivity(intent)
            },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Phone,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("اتصال هاتفي", fontSize = 12.sp)
          }

          OutlinedButton(
            onClick = {
              val msg = "مرحباً، أستفسر بخصوص معروضات حزب مستقبل وطن: ${product.title}"
              val uri = Uri.parse("https://api.whatsapp.com/send?phone=${product.whatsappNumber}&text=${Uri.encode(msg)}")
              val intent = Intent(Intent.ACTION_VIEW, uri)
              context.startActivity(intent)
            },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Chat,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
              tint = Color(0xFF25D366)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("واتساب", fontSize = 12.sp, color = Color(0xFF25D366))
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Live Chat Assistant button
        OutlinedButton(
          onClick = {
            onDismiss()
            onStartInquiryChat(product)
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Chat,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = PartyNavyDark
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "تحدث فورياً مع ممثل المنفذ",
            fontSize = 12.sp,
            color = PartyNavyDark,
            fontWeight = FontWeight.Bold
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Primary Add to Cart Button
        Button(
          onClick = {
            onAddToCart(product)
            onDismiss()
          },
          colors = ButtonDefaults.buttonColors(containerColor = PartyNavyDark),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
        ) {
          Icon(
            imageVector = Icons.Default.ShoppingCart,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "إضافة إلى سلة المشتريات والحجز الفوري",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
        }
      }
    }
  }
}
