package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CartItemEntity
import com.example.data.model.MarketFilterState
import com.example.data.model.MarketProductEntity
import com.example.data.model.MarketSortOption
import com.example.ui.theme.LightSkyBackground
import com.example.ui.theme.LightSkyBorder
import com.example.ui.theme.LightSkyPrimary
import com.example.ui.theme.LightSkySurfaceVariant
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary
import com.example.ui.theme.PhosphorGreen
import com.example.ui.theme.PhosphorGreenDark
import com.example.ui.theme.PhosphorGreenLight
import com.example.ui.theme.TextPrimaryDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketScreen(
  products: List<MarketProductEntity>,
  filterState: MarketFilterState,
  cartItems: List<CartItemEntity>,
  categories: List<String>,
  governorates: List<String>,
  onSearchChange: (String) -> Unit,
  onCategoryChange: (String) -> Unit,
  onGovernorateChange: (String) -> Unit,
  onToggleMemberDeals: () -> Unit,
  onToggleSaved: () -> Unit,
  onSortChange: (MarketSortOption) -> Unit,
  onProductClick: (MarketProductEntity) -> Unit,
  onAddToCart: (MarketProductEntity) -> Unit,
  onToggleSave: (MarketProductEntity) -> Unit,
  onOpenCart: () -> Unit,
  onOpenAddProduct: () -> Unit
) {
  var sortExpanded by remember { mutableStateOf(false) }
  var govExpanded by remember { mutableStateOf(false) }

  Scaffold(
    floatingActionButton = {
      Column(
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Add product FAB
        ExtendedFloatingActionButton(
          onClick = onOpenAddProduct,
          containerColor = PhosphorGreen,
          contentColor = TextPrimaryDark,
          icon = { Icon(Icons.Default.Add, contentDescription = null, tint = TextPrimaryDark) },
          text = { Text("أضف سلعتك / مشروعك", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark) },
          modifier = Modifier.testTag("add_product_fab")
        )

        // Cart FAB
        FloatingActionButton(
          onClick = onOpenCart,
          containerColor = PhosphorGreen,
          contentColor = TextPrimaryDark,
          modifier = Modifier.testTag("open_cart_fab")
        ) {
          BadgedBox(
            badge = {
              if (cartItems.isNotEmpty()) {
                Badge(
                  containerColor = Color(0xFFE53935),
                  contentColor = Color.White
                ) {
                  Text("${cartItems.sumOf { it.quantity }}")
                }
              }
            }
          ) {
            Icon(
              imageVector = Icons.Default.ShoppingCart,
              contentDescription = "سلة المشتريات",
              tint = TextPrimaryDark,
              modifier = Modifier.size(26.dp)
            )
          }
        }
      }
    }
  ) { paddingValues ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .background(LightSkyBackground)
        .padding(paddingValues),
      contentPadding = PaddingValues(bottom = 96.dp)
    ) {
      // 1. Promotional Hero Banner
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
              Brush.linearGradient(
                colors = listOf(Color(0xFF0369A1), Color(0xFF0284C7), PhosphorGreenDark)
              )
            )
            .padding(18.dp)
        ) {
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(12.dp))
                  .background(PhosphorGreen)
                  .padding(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.ElectricBolt,
                    contentDescription = null,
                    tint = TextPrimaryDark,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "عروض وشوادر التخفيض الكبرى",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                  )
                }
              }

              Text(
                text = "خصومات حتى 45%",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
              text = "سوق ومعارض حزب مستقبل وطن",
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
              text = "سلع تموينية، مستلزمات أهلاً بالمدارس، منتجات الأسر المنتجة ومشروعات الشباب بأسعار التكلفة لدعم كل بيت مصري.",
              style = MaterialTheme.typography.bodySmall.copy(
                color = Color.White.copy(alpha = 0.85f),
                lineHeight = 18.sp
              )
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "✨ دعم فوري لأعضاء الحزب بخصم إضافي",
                color = PartyGoldAccent,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
              )
              Text(
                text = "الخط الساخن: 16543",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      // 2. Search Field
      item {
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
          OutlinedTextField(
            value = filterState.searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("ابحث عن سلع، أجهزة، شوادر، معارض...", fontSize = 13.sp) },
            leadingIcon = {
              Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "بحث",
                tint = PartyNavyPrimary
              )
            },
            trailingIcon = {
              if (filterState.searchQuery.isNotEmpty()) {
                IconButton(onClick = { onSearchChange("") }) {
                  Icon(
                    imageVector = Icons.Default.Clear,
                    contentDescription = "مسح",
                    tint = Color.Gray
                  )
                }
              }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("market_search_input")
          )
        }
      }

      // 3. Filter Options (Governorate & Sort & Member deals & Saved)
      item {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Governorate Dropdown Box
          Box(modifier = Modifier.weight(1f)) {
            OutlinedButton(
              onClick = { govExpanded = true },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = PartyNavyPrimary
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (filterState.selectedGovernorate == "الكل") "كل المحافظات" else filterState.selectedGovernorate,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }

            DropdownMenu(
              expanded = govExpanded,
              onDismissRequest = { govExpanded = false }
            ) {
              governorates.forEach { gov ->
                DropdownMenuItem(
                  text = { Text(gov) },
                  onClick = {
                    onGovernorateChange(gov)
                    govExpanded = false
                  }
                )
              }
            }
          }

          // Sort Dropdown Box
          Box(modifier = Modifier.weight(1f)) {
            OutlinedButton(
              onClick = { sortExpanded = true },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(
                imageVector = Icons.Default.Sort,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = PartyNavyPrimary
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = filterState.sortBy.titleAr,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }

            DropdownMenu(
              expanded = sortExpanded,
              onDismissRequest = { sortExpanded = false }
            ) {
              MarketSortOption.values().forEach { sort ->
                DropdownMenuItem(
                  text = { Text(sort.titleAr) },
                  onClick = {
                    onSortChange(sort)
                    sortExpanded = false
                  }
                )
              }
            }
          }
        }
      }

      // 4. Quick Toggle Chips
      item {
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Member deals toggle
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .background(if (filterState.onlyMemberDeals) PhosphorGreen else Color.White)
              .border(
                1.dp,
                if (filterState.onlyMemberDeals) PhosphorGreenDark else LightSkyBorder,
                RoundedCornerShape(20.dp)
              )
              .clickable { onToggleMemberDeals() }
              .padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Verified,
                contentDescription = null,
                tint = if (filterState.onlyMemberDeals) TextPrimaryDark else PhosphorGreenDark,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "خصومات العضوية 🌟",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryDark
              )
            }
          }

          // Saved items toggle
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .background(if (filterState.onlySaved) Color(0xFFFFEBEE) else Color.White)
              .border(
                1.dp,
                if (filterState.onlySaved) Color.Red else LightSkyBorder,
                RoundedCornerShape(20.dp)
              )
              .clickable { onToggleSaved() }
              .padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (filterState.onlySaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = null,
                tint = if (filterState.onlySaved) Color.Red else Color.Gray,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "المفضلة ❤️",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (filterState.onlySaved) Color.Red else Color.Gray
              )
            }
          }
        }
      }

      // 5. Category Chips Horizontal Scroll
      item {
        Spacer(modifier = Modifier.height(12.dp))
        LazyRow(
          contentPadding = PaddingValues(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(categories) { cat ->
            val isSelected = filterState.selectedCategory == cat
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(if (isSelected) PhosphorGreenLight else Color.White)
                .border(
                  1.dp,
                  if (isSelected) PhosphorGreen else LightSkyBorder,
                  RoundedCornerShape(16.dp)
                )
                .clickable { onCategoryChange(cat) }
                .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
              Text(
                text = cat,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) PhosphorGreenDark else TextPrimaryDark
              )
            }
          }
        }
      }

      // 6. Section Header
      item {
        Spacer(modifier = Modifier.height(16.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "معروضات وسلع المبادرة (${products.size})",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = PartyNavyDark
            )
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
      }

      // 7. Empty State or Products List
      if (products.isEmpty()) {
        item {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(
              imageVector = Icons.Default.Storefront,
              contentDescription = null,
              modifier = Modifier.size(64.dp),
              tint = Color.LightGray
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "لا توجد نتائج مطابقة لبحثك",
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp,
              color = PartyNavyDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "جرّب تغيير التصنيف أو المحافظة أو مسح نص البحث",
              fontSize = 12.sp,
              color = Color.Gray
            )
          }
        }
      } else {
        items(products) { product ->
          ProductCard(
            product = product,
            onClick = { onProductClick(product) },
            onAddToCart = { onAddToCart(product) },
            onToggleSave = { onToggleSave(product) }
          )
        }
      }
    }
  }
}

@Composable
fun ProductCard(
  product: MarketProductEntity,
  onClick: () -> Unit,
  onAddToCart: () -> Unit,
  onToggleSave: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, LightSkyBorder),
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp)
      .clickable { onClick() }
      .testTag("product_card_${product.id}")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // Header row: Badges and Favorite button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          // Discount Badge
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFE53935))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = "خصم ${product.discountPercent}%",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }

          // Category Badge
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFEFF6FF))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = product.category,
              fontSize = 10.sp,
              fontWeight = FontWeight.Medium,
              color = PartyNavyPrimary
            )
          }

          if (product.isMemberExclusiveDiscount) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(PartyGoldAccent.copy(alpha = 0.2f))
                .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
              Text(
                text = "+${product.memberDiscountExtraPercent}% للعضوية",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = PartyNavyDark
              )
            }
          }
        }

        IconButton(
          onClick = onToggleSave,
          modifier = Modifier.size(32.dp)
        ) {
          Icon(
            imageVector = if (product.isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "حفظ",
            tint = if (product.isSaved) Color.Red else Color.LightGray,
            modifier = Modifier.size(20.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Product Title
      Text(
        text = product.title,
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          color = PartyNavyDark
        ),
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(4.dp))

      // Location & Seller
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(3.dp))
          Text(
            text = "${product.governorate} • ${product.locationDetails}",
            fontSize = 11.sp,
            color = Color.Gray,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Star,
            contentDescription = null,
            tint = PartyGoldAccent,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(2.dp))
          Text(
            text = "${product.rating}",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = PartyNavyDark
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Price & Add to Cart button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "${product.discountedPrice.toInt()} ج.م",
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2E7D32)
              )
            )
            if (product.originalPrice > product.discountedPrice) {
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "${product.originalPrice.toInt()} ج.م",
                style = MaterialTheme.typography.bodySmall.copy(
                  textDecoration = TextDecoration.LineThrough,
                  color = Color.Gray
                )
              )
            }
          }
          Text(
            text = "وفر ${(product.originalPrice - product.discountedPrice).toInt()} ج.م",
            fontSize = 10.sp,
            color = Color(0xFF2E7D32),
            fontWeight = FontWeight.Bold
          )
        }

        Button(
          onClick = onAddToCart,
          colors = ButtonDefaults.buttonColors(
            containerColor = PhosphorGreen,
            contentColor = TextPrimaryDark
          ),
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
          modifier = Modifier.testTag("add_to_cart_button_${product.id}")
        ) {
          Icon(
            imageVector = Icons.Default.ShoppingCart,
            contentDescription = null,
            tint = TextPrimaryDark,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "أضف للسلة",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimaryDark
          )
        }
      }
    }
  }
}
