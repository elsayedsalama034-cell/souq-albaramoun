package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.CartItemEntity
import com.example.data.model.CitizenRequestEntity
import com.example.data.model.InitiativeItem
import com.example.data.model.MarketChatMessage
import com.example.data.model.MarketFilterState
import com.example.data.model.MarketOrderEntity
import com.example.data.model.MarketProductEntity
import com.example.data.model.MarketPromoCoupon
import com.example.data.model.MarketSortOption
import com.example.data.model.MembershipApplicationEntity
import com.example.data.model.NewsItem
import com.example.data.model.ParliamentMember
import com.example.data.model.PartyOffice
import com.example.data.repository.PartyRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class PartyNavigationTab(val titleAr: String) {
  HOME("الرئيسية"),
  MARKETPLACE("سوق المعارض"),
  INITIATIVES("المبادرات"),
  CITIZEN_SERVICE("خدمة المواطنين"),
  MEMBERSHIP("العضوية"),
  DIRECTORY("المقرات والنواب"),
  DEPUTIES("النواب"),
  OFFICES("المقرات")
}

data class CitizenFormState(
  val citizenName: String = "",
  val nationalId: String = "",
  val phoneNumber: String = "",
  val governorate: String = "القاهرة",
  val requestType: String = "علاج على نفقة الدولة وقوافل طبية",
  val description: String = "",
  val isSubmitting: Boolean = false,
  val lastSubmittedCode: String? = null,
  val errorMessage: String? = null
)

data class MembershipFormState(
  val fullName: String = "",
  val nationalId: String = "",
  val phoneNumber: String = "",
  val governorate: String = "القاهرة",
  val district: String = "",
  val qualification: String = "",
  val preferredCommittee: String = "أمانة الشباب",
  val isSubmitting: Boolean = false,
  val lastMembershipCode: String? = null,
  val errorMessage: String? = null
)

data class NewProductFormState(
  val title: String = "",
  val category: String = "سلع غذائية وتموينية",
  val originalPrice: String = "",
  val discountedPrice: String = "",
  val governorate: String = "القاهرة",
  val locationDetails: String = "",
  val sellerName: String = "",
  val sellerType: String = "مشروع أسر منتجة",
  val phoneNumber: String = "",
  val whatsappNumber: String = "",
  val description: String = "",
  val isMemberExclusive: Boolean = true,
  val memberExtraPercent: String = "10",
  val condition: String = "جديد ومغلف",
  val imageType: String = "food_basket",
  val isSubmitting: Boolean = false,
  val errorMessage: String? = null
)

class PartyViewModel(application: Application) : AndroidViewModel(application) {

  private val repository: PartyRepository

  val citizenRequests: StateFlow<List<CitizenRequestEntity>>
  val memberships: StateFlow<List<MembershipApplicationEntity>>

  private val _currentTab = MutableStateFlow(PartyNavigationTab.HOME)
  val currentTab: StateFlow<PartyNavigationTab> = _currentTab.asStateFlow()

  private val _newsList = MutableStateFlow<List<NewsItem>>(emptyList())
  val newsList: StateFlow<List<NewsItem>> = _newsList.asStateFlow()

  private val _selectedNews = MutableStateFlow<NewsItem?>(null)
  val selectedNews: StateFlow<NewsItem?> = _selectedNews.asStateFlow()

  private val _initiatives = MutableStateFlow<List<InitiativeItem>>(emptyList())
  val initiatives: StateFlow<List<InitiativeItem>> = _initiatives.asStateFlow()

  private val _selectedInitiative = MutableStateFlow<InitiativeItem?>(null)
  val selectedInitiative: StateFlow<InitiativeItem?> = _selectedInitiative.asStateFlow()

  private val _deputies = MutableStateFlow<List<ParliamentMember>>(emptyList())
  val deputies: StateFlow<List<ParliamentMember>> = _deputies.asStateFlow()

  private val _offices = MutableStateFlow<List<PartyOffice>>(emptyList())
  val offices: StateFlow<List<PartyOffice>> = _offices.asStateFlow()

  // Market & E-Commerce State
  val allMarketProducts: StateFlow<List<MarketProductEntity>>

  private val _marketFilter = MutableStateFlow(MarketFilterState())
  val marketFilter: StateFlow<MarketFilterState> = _marketFilter.asStateFlow()

  val filteredMarketProducts: StateFlow<List<MarketProductEntity>>

  private val _selectedMarketProduct = MutableStateFlow<MarketProductEntity?>(null)
  val selectedMarketProduct: StateFlow<MarketProductEntity?> = _selectedMarketProduct.asStateFlow()

  private val _showAddProductDialog = MutableStateFlow(false)
  val showAddProductDialog: StateFlow<Boolean> = _showAddProductDialog.asStateFlow()

  private val _newProductForm = MutableStateFlow(NewProductFormState())
  val newProductForm: StateFlow<NewProductFormState> = _newProductForm.asStateFlow()

  // Chat State
  private val _inquiryProduct = MutableStateFlow<MarketProductEntity?>(null)
  val inquiryProduct: StateFlow<MarketProductEntity?> = _inquiryProduct.asStateFlow()

  private val _chatMessages = MutableStateFlow<List<MarketChatMessage>>(emptyList())
  val chatMessages: StateFlow<List<MarketChatMessage>> = _chatMessages.asStateFlow()

  // Cart & Orders State
  val cartItems: StateFlow<List<CartItemEntity>>
  val marketOrders: StateFlow<List<MarketOrderEntity>>
  val promoCoupons: List<MarketPromoCoupon>

  private val _appliedCoupon = MutableStateFlow<MarketPromoCoupon?>(null)
  val appliedCoupon: StateFlow<MarketPromoCoupon?> = _appliedCoupon.asStateFlow()

  private val _showCartDialog = MutableStateFlow(false)
  val showCartDialog: StateFlow<Boolean> = _showCartDialog.asStateFlow()

  private val _showOrdersDialog = MutableStateFlow(false)
  val showOrdersDialog: StateFlow<Boolean> = _showOrdersDialog.asStateFlow()

  private val _isPlacingOrder = MutableStateFlow(false)
  val isPlacingOrder: StateFlow<Boolean> = _isPlacingOrder.asStateFlow()

  // Filter states
  private val _deputiesSearchQuery = MutableStateFlow("")
  val deputiesSearchQuery: StateFlow<String> = _deputiesSearchQuery.asStateFlow()

  private val _selectedGovernorateFilter = MutableStateFlow("الكل")
  val selectedGovernorateFilter: StateFlow<String> = _selectedGovernorateFilter.asStateFlow()

  // Forms
  private val _citizenForm = MutableStateFlow(CitizenFormState())
  val citizenForm: StateFlow<CitizenFormState> = _citizenForm.asStateFlow()

  private val _membershipForm = MutableStateFlow(MembershipFormState())
  val membershipForm: StateFlow<MembershipFormState> = _membershipForm.asStateFlow()

  // Feedback message
  private val _toastMessage = MutableStateFlow<String?>(null)
  val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

  val governorates: List<String>
  val committees: List<String>
  val requestTypes: List<String>
  val marketCategories: List<String>

  init {
    val db = AppDatabase.getDatabase(application)
    repository = PartyRepository(
      citizenRequestDao = db.citizenRequestDao(),
      membershipDao = db.membershipDao(),
      marketProductDao = db.marketProductDao(),
      cartDao = db.cartDao(),
      marketOrderDao = db.marketOrderDao()
    )

    citizenRequests = repository.citizenRequests.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

    memberships = repository.memberships.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

    allMarketProducts = repository.marketProducts.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

    cartItems = repository.cartItems.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

    marketOrders = repository.marketOrders.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

    promoCoupons = repository.promoCoupons

    filteredMarketProducts = combine(allMarketProducts, _marketFilter) { products, filter ->
      products.filter { p ->
        val matchesQuery = filter.searchQuery.isBlank() ||
          p.title.contains(filter.searchQuery, ignoreCase = true) ||
          p.description.contains(filter.searchQuery, ignoreCase = true) ||
          p.sellerName.contains(filter.searchQuery, ignoreCase = true) ||
          p.locationDetails.contains(filter.searchQuery, ignoreCase = true)

        val matchesCategory = filter.selectedCategory == "الكل" || p.category == filter.selectedCategory
        val matchesGov = filter.selectedGovernorate == "الكل" || p.governorate == filter.selectedGovernorate
        val matchesMember = !filter.onlyMemberDeals || p.isMemberExclusiveDiscount
        val matchesSaved = !filter.onlySaved || p.isSaved

        matchesQuery && matchesCategory && matchesGov && matchesMember && matchesSaved
      }.let { list ->
        when (filter.sortBy) {
          MarketSortOption.NEWEST -> list.sortedByDescending { it.id }
          MarketSortOption.LOWEST_PRICE -> list.sortedBy { it.discountedPrice }
          MarketSortOption.HIGHEST_DISCOUNT -> list.sortedByDescending { it.discountPercent }
          MarketSortOption.TOP_RATED -> list.sortedByDescending { it.rating }
        }
      }
    }.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

    governorates = repository.governoratesList
    committees = repository.committeesList
    requestTypes = repository.requestTypes
    marketCategories = repository.marketCategories

    _newsList.value = repository.getNewsList()
    _initiatives.value = repository.getInitiatives()
    _deputies.value = repository.getDeputies()
    _offices.value = repository.getOffices()

    viewModelScope.launch {
      repository.seedMarketProductsIfEmpty()
    }
  }

  fun setTab(tab: PartyNavigationTab) {
    _currentTab.value = tab
  }

  fun selectNews(news: NewsItem?) {
    _selectedNews.value = news
  }

  fun selectInitiative(initiative: InitiativeItem?) {
    _selectedInitiative.value = initiative
  }

  fun setDeputiesSearch(query: String) {
    _deputiesSearchQuery.value = query
  }

  fun setGovernorateFilter(gov: String) {
    _selectedGovernorateFilter.value = gov
  }

  fun clearToast() {
    _toastMessage.value = null
  }

  // --- Market Actions ---
  fun setMarketSearch(query: String) {
    _marketFilter.value = _marketFilter.value.copy(searchQuery = query)
  }

  fun setMarketCategory(category: String) {
    _marketFilter.value = _marketFilter.value.copy(selectedCategory = category)
  }

  fun setMarketGovernorate(gov: String) {
    _marketFilter.value = _marketFilter.value.copy(selectedGovernorate = gov)
  }

  fun toggleOnlyMemberDeals() {
    _marketFilter.value = _marketFilter.value.copy(onlyMemberDeals = !_marketFilter.value.onlyMemberDeals)
  }

  fun toggleOnlySaved() {
    _marketFilter.value = _marketFilter.value.copy(onlySaved = !_marketFilter.value.onlySaved)
  }

  fun setMarketSort(sort: MarketSortOption) {
    _marketFilter.value = _marketFilter.value.copy(sortBy = sort)
  }

  fun toggleProductSave(product: MarketProductEntity) {
    viewModelScope.launch {
      val newStatus = !product.isSaved
      repository.toggleSaveProduct(product.id, newStatus)
      if (newStatus) {
        _toastMessage.value = "تم حفظ '${product.title}' في قائمة المفضلة ❤️"
      } else {
        _toastMessage.value = "تمت إزالة السلعة من المفضلة"
      }
    }
  }

  fun selectMarketProduct(product: MarketProductEntity?) {
    _selectedMarketProduct.value = product
  }

  fun openAddProductDialog() {
    _newProductForm.value = NewProductFormState()
    _showAddProductDialog.value = true
  }

  fun closeAddProductDialog() {
    _showAddProductDialog.value = false
  }

  fun updateNewProductTitle(v: String) {
    _newProductForm.value = _newProductForm.value.copy(title = v, errorMessage = null)
  }

  fun updateNewProductCategory(v: String) {
    _newProductForm.value = _newProductForm.value.copy(category = v)
  }

  fun updateNewProductOriginalPrice(v: String) {
    if (v.isEmpty() || v.all { it.isDigit() || it == '.' }) {
      _newProductForm.value = _newProductForm.value.copy(originalPrice = v, errorMessage = null)
    }
  }

  fun updateNewProductDiscountedPrice(v: String) {
    if (v.isEmpty() || v.all { it.isDigit() || it == '.' }) {
      _newProductForm.value = _newProductForm.value.copy(discountedPrice = v, errorMessage = null)
    }
  }

  fun updateNewProductGovernorate(v: String) {
    _newProductForm.value = _newProductForm.value.copy(governorate = v)
  }

  fun updateNewProductLocation(v: String) {
    _newProductForm.value = _newProductForm.value.copy(locationDetails = v, errorMessage = null)
  }

  fun updateNewProductSellerName(v: String) {
    _newProductForm.value = _newProductForm.value.copy(sellerName = v, errorMessage = null)
  }

  fun updateNewProductSellerType(v: String) {
    _newProductForm.value = _newProductForm.value.copy(sellerType = v)
  }

  fun updateNewProductPhone(v: String) {
    if (v.length <= 11 && v.all { it.isDigit() }) {
      _newProductForm.value = _newProductForm.value.copy(phoneNumber = v, errorMessage = null)
    }
  }

  fun updateNewProductWhatsapp(v: String) {
    if (v.length <= 13 && v.all { it.isDigit() }) {
      _newProductForm.value = _newProductForm.value.copy(whatsappNumber = v)
    }
  }

  fun updateNewProductDescription(v: String) {
    _newProductForm.value = _newProductForm.value.copy(description = v, errorMessage = null)
  }

  fun updateNewProductCondition(v: String) {
    _newProductForm.value = _newProductForm.value.copy(condition = v)
  }

  fun updateNewProductMemberExclusive(v: Boolean) {
    _newProductForm.value = _newProductForm.value.copy(isMemberExclusive = v)
  }

  fun updateNewProductMemberExtraPercent(v: String) {
    _newProductForm.value = _newProductForm.value.copy(memberExtraPercent = v)
  }

  fun updateNewProductImageType(v: String) {
    _newProductForm.value = _newProductForm.value.copy(imageType = v)
  }

  fun submitNewProduct() {
    val form = _newProductForm.value
    if (form.title.trim().length < 5) {
      _newProductForm.value = form.copy(errorMessage = "يرجى كتابة عنوان واضح للإعلان (5 أحرف على الأقل)")
      return
    }
    val discPrice = form.discountedPrice.toDoubleOrNull() ?: 0.0
    val origPrice = form.originalPrice.toDoubleOrNull() ?: (discPrice * 1.25)
    if (discPrice <= 0.0) {
      _newProductForm.value = form.copy(errorMessage = "يرجى إدخال سعر البيع المخفض بشكل صحيح")
      return
    }
    if (form.sellerName.trim().length < 3) {
      _newProductForm.value = form.copy(errorMessage = "يرجى إدخال اسم العارض أو التاجر أو المشروع")
      return
    }
    if (form.phoneNumber.length < 10) {
      _newProductForm.value = form.copy(errorMessage = "يرجى إدخال رقم هاتف صحيح للتواصل")
      return
    }
    if (form.description.trim().length < 8) {
      _newProductForm.value = form.copy(errorMessage = "يرجى كتابة وصف تفصيلي للسلعة ومحتواها")
      return
    }

    _newProductForm.value = form.copy(isSubmitting = true, errorMessage = null)
    viewModelScope.launch {
      try {
        val extraPercent = form.memberExtraPercent.toIntOrNull() ?: 10
        repository.addMarketProduct(
          title = form.title.trim(),
          category = form.category,
          originalPrice = origPrice,
          discountedPrice = discPrice,
          governorate = form.governorate,
          locationDetails = form.locationDetails.ifBlank { "مقر معرض الحزب بالمحافظة" },
          sellerName = form.sellerName.trim(),
          sellerType = form.sellerType,
          phoneNumber = form.phoneNumber,
          whatsappNumber = form.whatsappNumber.ifBlank { "20" + form.phoneNumber },
          description = form.description.trim(),
          isMemberExclusive = form.isMemberExclusive,
          memberExtraPercent = extraPercent,
          condition = form.condition,
          imageType = form.imageType
        )
        _showAddProductDialog.value = false
        _toastMessage.value = "تم إضافة سلعتك لسوق معارض مستقبل وطن بنجاح!"
      } catch (e: Exception) {
        _newProductForm.value = form.copy(
          isSubmitting = false,
          errorMessage = "حدث خطأ أثناء النشر، يرجى المحاولة ثانية"
        )
      }
    }
  }

  // --- Live Inquiry Chat Actions ---
  fun openInquiryChat(product: MarketProductEntity) {
    _inquiryProduct.value = product
    val timeFormat = SimpleDateFormat("hh:mm a", Locale("ar", "EG"))
    val initialTime = timeFormat.format(Date())
    _chatMessages.value = listOf(
      MarketChatMessage(
        id = "1",
        productId = product.id,
        text = "مرحباً بك! أنا ممثل خدمة العملاء ومسؤول العارضين لـ (${product.sellerName}). تفضل بأي استفسار حول سلعة '${product.title}' أو أماكن التوافر ونسب الخصم المتاحة لحاملي كارنيه الحزب.",
        isFromUser = false,
        time = initialTime
      )
    )
  }

  fun closeInquiryChat() {
    _inquiryProduct.value = null
    _chatMessages.value = emptyList()
  }

  fun sendChatMessage(text: String) {
    if (text.isBlank()) return
    val product = _inquiryProduct.value ?: return
    val timeFormat = SimpleDateFormat("hh:mm a", Locale("ar", "EG"))
    val currentTime = timeFormat.format(Date())

    val userMsg = MarketChatMessage(
      id = System.currentTimeMillis().toString(),
      productId = product.id,
      text = text.trim(),
      isFromUser = true,
      time = currentTime
    )
    _chatMessages.value = _chatMessages.value + userMsg

    viewModelScope.launch {
      delay(800)
      val replyText = when {
        text.contains("سعر") || text.contains("خصم") || text.contains("كام") -> {
          "سعر السلعة الحالي ${product.discountedPrice.toInt()} ج.م بتخفيض ${product.discountPercent}% عن السوق الحر، وإذا كنت حاملاً لبطاقة عضوية حزب مستقبل وطن تحصل على خصم إضافي وفوري ${product.memberDiscountExtraPercent}% بمجرد إبراز البطاقة في المعرض."
        }
        text.contains("عنوان") || text.contains("مكان") || text.contains("فين") || text.contains("موقع") -> {
          "تتواجد السلعة في منفذ: ${product.locationDetails} بمحافظة ${product.governorate}. كما يمكنك التواصل المباشر مع المنفذ على الهاتف: ${product.phoneNumber}."
        }
        text.contains("مواعيد") || text.contains("شغالين") || text.contains("مفتوح") || text.contains("ساعة") -> {
          "معارض ومنافذ الحزب تفتح أبوابها يومياً من الساعة 9:00 صباحاً وحتى الساعة 10:00 مساءً، بما في ذلك أيام العطلات الأسبوعية والإجازات الرسمية."
        }
        text.contains("توصيل") || text.contains("دليفري") || text.contains("شحن") -> {
          "تتوفر خدمة الشحن والتوصيل للمنازل بالتنسيق مع أمانة العمل الجماهيري، يرجى الاتصال على الخط الساخن 16543 أو مراسلتنا عبر الواتساب على ${product.whatsappNumber} لتأكيد العنوان."
        }
        else -> {
          "أهلاً بك! تم تسجيل استفسارك باهتمام، ويمكنك أيضاً الاتصال هاتفياً بالعارض مباشرة على الرقم ${product.phoneNumber}. نحن دائماً في خدمتكم لدعم المواطن المصري وتخفيف الأعباء المعيشية."
        }
      }

      val sellerReply = MarketChatMessage(
        id = (System.currentTimeMillis() + 1).toString(),
        productId = product.id,
        text = replyText,
        isFromUser = false,
        time = timeFormat.format(Date())
      )
      _chatMessages.value = _chatMessages.value + sellerReply
    }
  }

  // --- Cart & Orders Actions ---
  fun openCartDialog() {
    _showCartDialog.value = true
  }

  fun closeCartDialog() {
    _showCartDialog.value = false
  }

  fun openOrdersDialog() {
    _showOrdersDialog.value = true
  }

  fun closeOrdersDialog() {
    _showOrdersDialog.value = false
  }

  fun addToCart(product: MarketProductEntity, quantity: Int = 1) {
    viewModelScope.launch {
      repository.addToCart(product, quantity)
      _toastMessage.value = "تمت إضافة '${product.title}' إلى سلة المشتريات 🛒"
    }
  }

  fun updateCartItemQuantity(cartItem: CartItemEntity, newQuantity: Int) {
    viewModelScope.launch {
      repository.updateCartQuantity(cartItem, newQuantity)
    }
  }

  fun removeCartItem(cartItem: CartItemEntity) {
    viewModelScope.launch {
      repository.removeCartItem(cartItem)
      _toastMessage.value = "تم حذف السلعة من السلة"
    }
  }

  fun clearCart() {
    viewModelScope.launch {
      repository.clearCart()
      _toastMessage.value = "تم إفراغ السلة"
    }
  }

  fun applyCoupon(code: String) {
    val cleanCode = code.trim().uppercase()
    val match = promoCoupons.find { it.code.equals(cleanCode, ignoreCase = true) }
    if (match != null) {
      _appliedCoupon.value = match
      _toastMessage.value = "تم تطبيق الكود الترويجي (${match.code}) بنجاح! 🎉"
    } else {
      _toastMessage.value = "الكود الترويجي غير صحيح أو منتهي الصلاحية"
    }
  }

  fun removeCoupon() {
    _appliedCoupon.value = null
  }

  fun checkoutOrder(
    customerName: String,
    phoneNumber: String,
    deliveryType: String,
    outletOrAddress: String,
    itemsCount: Int,
    totalAmount: Double,
    totalSaved: Double
  ) {
    if (customerName.trim().length < 3) {
      _toastMessage.value = "يرجى كتابة الاسم بالكامل لتأكيد الحجز"
      return
    }
    if (phoneNumber.length != 11) {
      _toastMessage.value = "يرجى كتابة رقم هاتف صحيح مكون من 11 رقماً"
      return
    }
    if (outletOrAddress.trim().isEmpty()) {
      _toastMessage.value = "يرجى تحديد عنوان التوصيل أو اسم المنفذ للاستلام"
      return
    }

    _isPlacingOrder.value = true
    viewModelScope.launch {
      try {
        val orderCode = repository.placeMarketOrder(
          customerName = customerName.trim(),
          phoneNumber = phoneNumber,
          deliveryType = deliveryType,
          outletOrAddress = outletOrAddress.trim(),
          itemsCount = itemsCount,
          totalAmount = totalAmount,
          totalSaved = totalSaved,
          appliedCoupon = _appliedCoupon.value?.code
        )
        _isPlacingOrder.value = false
        _showCartDialog.value = false
        _appliedCoupon.value = null
        _toastMessage.value = "تم حجز وتأكيد طلبك بنجاح! كود المتابعة: $orderCode"
      } catch (e: Exception) {
        _isPlacingOrder.value = false
        _toastMessage.value = "حدث خطأ أثناء تأكيد الطلب، يرجى المحاولة ثانية"
      }
    }
  }

  // --- Citizen Form Handlers ---
  fun updateCitizenName(name: String) {
    _citizenForm.value = _citizenForm.value.copy(citizenName = name, errorMessage = null)
  }

  fun updateCitizenNationalId(id: String) {
    if (id.length <= 14 && id.all { it.isDigit() }) {
      _citizenForm.value = _citizenForm.value.copy(nationalId = id, errorMessage = null)
    }
  }

  fun updateCitizenPhone(phone: String) {
    if (phone.length <= 11 && phone.all { it.isDigit() }) {
      _citizenForm.value = _citizenForm.value.copy(phoneNumber = phone, errorMessage = null)
    }
  }

  fun updateCitizenGovernorate(gov: String) {
    _citizenForm.value = _citizenForm.value.copy(governorate = gov)
  }

  fun updateCitizenRequestType(type: String) {
    _citizenForm.value = _citizenForm.value.copy(requestType = type)
  }

  fun updateCitizenDescription(desc: String) {
    _citizenForm.value = _citizenForm.value.copy(description = desc, errorMessage = null)
  }

  fun submitCitizenRequest() {
    val state = _citizenForm.value
    if (state.citizenName.trim().length < 3) {
      _citizenForm.value = state.copy(errorMessage = "يرجى كتابة الاسم الثلاثي بالكامل")
      return
    }
    if (state.nationalId.length != 14) {
      _citizenForm.value = state.copy(errorMessage = "الرقم القومي يجب أن يتكون من 14 رقماً")
      return
    }
    if (state.phoneNumber.length != 11) {
      _citizenForm.value = state.copy(errorMessage = "رقم الهاتف يجب أن يتكون من 11 رقماً (مثال: 010...)")
      return
    }
    if (state.description.trim().length < 10) {
      _citizenForm.value = state.copy(errorMessage = "يرجى شرح تفاصيل الطلب بشكل واضح (10 أحرف على الأقل)")
      return
    }

    _citizenForm.value = state.copy(isSubmitting = true, errorMessage = null)
    viewModelScope.launch {
      try {
        val trackingCode = repository.submitCitizenRequest(
          name = state.citizenName.trim(),
          nationalId = state.nationalId,
          phone = state.phoneNumber,
          governorate = state.governorate,
          type = state.requestType,
          description = state.description.trim()
        )
        _citizenForm.value = CitizenFormState(lastSubmittedCode = trackingCode)
        _toastMessage.value = "تم تسجيل طلبك بنجاح! رقم المتابعة: $trackingCode"
      } catch (e: Exception) {
        _citizenForm.value = state.copy(
          isSubmitting = false,
          errorMessage = "حدث خطأ أثناء الحفظ، يرجى المحاولة ثانية"
        )
      }
    }
  }

  fun deleteCitizenRequest(id: Long) {
    viewModelScope.launch {
      repository.deleteRequest(id)
      _toastMessage.value = "تم حذف الطلب من السجل المحلي"
    }
  }

  // --- Membership Form Handlers ---
  fun updateMembershipFullName(name: String) {
    _membershipForm.value = _membershipForm.value.copy(fullName = name, errorMessage = null)
  }

  fun updateMembershipNationalId(id: String) {
    if (id.length <= 14 && id.all { it.isDigit() }) {
      _membershipForm.value = _membershipForm.value.copy(nationalId = id, errorMessage = null)
    }
  }

  fun updateMembershipPhone(phone: String) {
    if (phone.length <= 11 && phone.all { it.isDigit() }) {
      _membershipForm.value = _membershipForm.value.copy(phoneNumber = phone, errorMessage = null)
    }
  }

  fun updateMembershipGovernorate(gov: String) {
    _membershipForm.value = _membershipForm.value.copy(governorate = gov)
  }

  fun updateMembershipDistrict(district: String) {
    _membershipForm.value = _membershipForm.value.copy(district = district, errorMessage = null)
  }

  fun updateMembershipQualification(qual: String) {
    _membershipForm.value = _membershipForm.value.copy(qualification = qual, errorMessage = null)
  }

  fun updateMembershipCommittee(comm: String) {
    _membershipForm.value = _membershipForm.value.copy(preferredCommittee = comm)
  }

  fun submitMembership() {
    val state = _membershipForm.value
    if (state.fullName.trim().length < 4) {
      _membershipForm.value = state.copy(errorMessage = "يرجى إدخال الاسم الرباعي كما هو ببطاقة الرقم القومي")
      return
    }
    if (state.nationalId.length != 14) {
      _membershipForm.value = state.copy(errorMessage = "الرقم القومي يجب أن يتكون من 14 رقماً")
      return
    }
    if (state.phoneNumber.length != 11) {
      _membershipForm.value = state.copy(errorMessage = "رقم الهاتف غير صحيح (11 رقماً)")
      return
    }
    if (state.district.trim().isEmpty()) {
      _membershipForm.value = state.copy(errorMessage = "يرجى تحديد المركز أو الحي التابع له")
      return
    }

    _membershipForm.value = state.copy(isSubmitting = true, errorMessage = null)
    viewModelScope.launch {
      try {
        val code = repository.submitMembership(
          fullName = state.fullName.trim(),
          nationalId = state.nationalId,
          phone = state.phoneNumber,
          governorate = state.governorate,
          district = state.district.trim(),
          qualification = state.qualification.trim(),
          preferredCommittee = state.preferredCommittee
        )
        _membershipForm.value = MembershipFormState(lastMembershipCode = code)
        _toastMessage.value = "أهلاً بك في حزب مستقبل وطن! كود العضوية: $code"
      } catch (e: Exception) {
        _membershipForm.value = state.copy(
          isSubmitting = false,
          errorMessage = "حدث خطأ أثناء إرسال استمارة العضوية"
        )
      }
    }
  }
}
