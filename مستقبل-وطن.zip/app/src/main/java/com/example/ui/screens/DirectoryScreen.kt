package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.data.model.ParliamentMember
import com.example.data.model.PartyOffice
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyNavyDark

@Composable
fun DirectoryScreen(
  deputies: List<ParliamentMember>,
  offices: List<PartyOffice>,
  searchQuery: String,
  selectedGovernorate: String,
  governorates: List<String>,
  onSearchChange: (String) -> Unit,
  onGovernorateChange: (String) -> Unit
) {
  var selectedSubTab by remember { mutableStateOf(0) }

  Column(modifier = Modifier.fillMaxSize()) {
    TabRow(
      selectedTabIndex = selectedSubTab,
      containerColor = PartyNavyDark,
      contentColor = Color.White,
      indicator = { tabPositions ->
        TabRowDefaults.Indicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSubTab]),
          color = PartyGoldAccent
        )
      },
      modifier = Modifier.fillMaxWidth()
    ) {
      Tab(
        selected = selectedSubTab == 0,
        onClick = { selectedSubTab = 0 },
        text = {
          Text(
            text = "هيئة نواب الحزب (${deputies.size})",
            fontSize = 13.sp,
            fontWeight = if (selectedSubTab == 0) FontWeight.Bold else FontWeight.Normal,
            color = if (selectedSubTab == 0) PartyGoldAccent else Color.White
          )
        }
      )
      Tab(
        selected = selectedSubTab == 1,
        onClick = { selectedSubTab = 1 },
        text = {
          Text(
            text = "المقرات والأمانات (${offices.size})",
            fontSize = 13.sp,
            fontWeight = if (selectedSubTab == 1) FontWeight.Bold else FontWeight.Normal,
            color = if (selectedSubTab == 1) PartyGoldAccent else Color.White
          )
        }
      )
    }

    if (selectedSubTab == 0) {
      DeputiesScreen(
        deputies = deputies,
        searchQuery = searchQuery,
        selectedGovernorate = selectedGovernorate,
        governorates = governorates,
        onSearchChange = onSearchChange,
        onGovernorateChange = onGovernorateChange
      )
    } else {
      OfficesScreen(offices = offices)
    }
  }
}
