package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InitiativeItem
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyGoldDark
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary
import com.example.ui.theme.TextSecondaryDark

@Composable
fun InitiativesScreen(
  initiatives: List<InitiativeItem>,
  onInitiativeClick: (InitiativeItem) -> Unit
) {
  var selectedCategory by remember { mutableStateOf("الكل") }

  val categories = listOf("الكل", "القطاع الصحي", "الدعم التمويني والغذائي", "الشباب والرياضة", "التعليم وبناء الإنسان", "التكافل الاجتماعي")

  val filteredList = if (selectedCategory == "الكل") {
    initiatives
  } else {
    initiatives.filter { it.category == selectedCategory }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .testTag("initiatives_screen")
  ) {
    // Top banner description
    Surface(
      color = PartyNavyDark,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 14.dp)
      ) {
        Text(
          text = "مبادرات مستقبل وطن المجتمعية",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "حملات صحية، معارض السلع التموينية، مسابقات شبابية، وبرامج التكافل في 27 محافظة",
          style = MaterialTheme.typography.bodySmall.copy(
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 12.sp
          )
        )
      }
    }

    // Filter Chips Row
    LazyRow(
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(categories) { category ->
        val isSelected = selectedCategory == category
        FilterChip(
          selected = isSelected,
          onClick = { selectedCategory = category },
          label = {
            Text(
              text = category,
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            )
          },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = PartyNavyPrimary,
            selectedLabelColor = Color.White,
            containerColor = MaterialTheme.colorScheme.surfaceVariant
          )
        )
      }
    }

    // Initiatives List
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      item {
        Text(
          text = "عدد المبادرات المتاحة: ${filteredList.size}",
          style = MaterialTheme.typography.labelMedium.copy(
            color = TextSecondaryDark,
            fontWeight = FontWeight.Medium
          )
        )
      }

      items(filteredList) { initiative ->
        InitiativeFullCard(
          initiative = initiative,
          onClick = { onInitiativeClick(initiative) }
        )
      }
    }
  }
}

@Composable
private fun InitiativeFullCard(
  initiative: InitiativeItem,
  onClick: () -> Unit
) {
  val (icon, iconBg) = when (initiative.iconType) {
    "medical" -> Icons.Default.HealthAndSafety to Color(0xFFE53935)
    "food" -> Icons.Default.Restaurant to Color(0xFFFB8C00)
    "sports" -> Icons.Default.SportsSoccer to Color(0xFF43A047)
    "education" -> Icons.Default.MenuBook to Color(0xFF1E88E5)
    else -> Icons.Default.VolunteerActivism to PartyGoldDark
  }

  ElevatedCard(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(iconBg.copy(alpha = 0.14f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconBg,
            modifier = Modifier.size(26.dp)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
          Surface(
            color = PartyGoldAccent.copy(alpha = 0.2f),
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = initiative.category,
              style = MaterialTheme.typography.labelSmall.copy(
                color = PartyGoldDark,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
              ),
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = initiative.title,
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = initiative.description,
        style = MaterialTheme.typography.bodyMedium.copy(
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontSize = 13.sp,
          lineHeight = 18.sp
        )
      )

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          Icons.Default.LocationOn,
          contentDescription = null,
          tint = PartyNavyPrimary,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = initiative.location,
          style = MaterialTheme.typography.bodySmall.copy(
            color = TextSecondaryDark,
            fontSize = 11.sp
          )
        )
      }

      Spacer(modifier = Modifier.height(4.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          Icons.Default.CalendarToday,
          contentDescription = null,
          tint = TextSecondaryDark,
          modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = initiative.date,
          style = MaterialTheme.typography.bodySmall.copy(
            color = TextSecondaryDark,
            fontSize = 11.sp
          )
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          color = PartyNavyPrimary.copy(alpha = 0.08f),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(
            text = initiative.beneficiariesCount,
            style = MaterialTheme.typography.labelSmall.copy(
              color = PartyNavyPrimary,
              fontWeight = FontWeight.Bold
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }

        Text(
          text = "تفاصيل والتسجيل ←",
          style = MaterialTheme.typography.labelSmall.copy(
            color = PartyNavyPrimary,
            fontWeight = FontWeight.Bold
          )
        )
      }
    }
  }
}
