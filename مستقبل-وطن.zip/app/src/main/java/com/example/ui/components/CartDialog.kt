package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Discount
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CartItemEntity
import com.example.data.model.MarketPromoCoupon
import com.example.ui.theme.LightSkyBorder
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary
import com.example.ui.theme.PhosphorGreen
import com.example.ui.theme.PhosphorGreenDark
import com.example.ui.theme.PhosphorGreenLight
import com.example.ui.theme.TextPrimaryDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartDialog(
  cartItems: List<CartItemEntity>,
  appliedCoupon: MarketPromoCoupon?,
  availableCoupons: List<MarketPromoCoupon>,
  isPlacingOrder: Boolean,
  onDismiss: () -> Unit,
  onUpdateQuantity: (CartItemEntity, Int) -> Unit,
  onRemoveItem: (CartItemEntity) -> Unit,
  onClearCart: () -> Unit,
  onApplyCoupon: (String) -> Unit,
  onRemoveCoupon: () -> Unit,
  onCheckout: (name: String, phone: String, deliveryType: String, outletOrAddress: String, itemsCount: Int, totalAmount: Double, totalSaved: Double) -> Unit
) {
  var couponInput by remember { mutableStateOf("") }
  var deliveryType by remember { mutableStateOf("استلام من منفذ الحزب") } // or "توصيل منزلي"
  var customerName by remember { mutableStateOf("") }
  var customerPhone by remember { mutableStateOf("") }
  var customerAddress by remember { mutableStateOf("") }
  var showCheckoutForm by remember { mutableStateOf(false) }

  // Calculations
  val originalTotal = cartItems.sumOf { it.originalPrice * it.quantity }
  val discountedSubtotal = cartItems.sumOf { it.unitPrice * it.quantity }
  val initiativeSavings = (originalTotal - discountedSubtotal).coerceAtLeast(0.0)

  val couponDiscount = when {
    appliedCoupon == null -> 0.0
    appliedCoupon.isPercentage -> (discountedSubtotal * (appliedCoupon.discountAmount / 100.0))
    else -> appliedCoupon.discountAmount
  }.coerceAtMost(discountedSubtotal)

  val deliveryFee = if (deliveryType == "توصيل منزلي") 20.0 else 0.0
  val finalTotal = (discountedSubtotal - couponDiscount + deliveryFee).coerceAtLeast(0.0)
  val totalSavings = initiativeSavings + couponDiscount

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .heightIn(max = 680.dp)
        .clip(RoundedCornerShape(24.dp)),
      color = Color.White,
      tonalElevation = 8.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(PhosphorGreenLight),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.ShoppingCart,
                contentDescription = "سلة المشتريات",
                tint = PhosphorGreenDark
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "سلة مشتريات المعارض",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = PartyNavyDark
                )
              )
              Text(
                text = if (cartItems.isEmpty()) "السلة فارغة" else "${cartItems.sumOf { it.quantity }} قطعة مختارة",
                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
              )
            }
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            if (cartItems.isNotEmpty()) {
              TextButton(
                onClick = onClearCart,
                modifier = Modifier.testTag("clear_cart_button")
              ) {
                Text(
                  text = "إفراغ",
                  color = Color.Red,
                  fontSize = 12.sp
                )
              }
            }
            IconButton(
              onClick = onDismiss,
              modifier = Modifier.size(36.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "إغلاق",
                tint = Color.Gray
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (cartItems.isEmpty()) {
          // Empty Cart State
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.ShoppingCart,
              contentDescription = null,
              modifier = Modifier.size(72.dp),
              tint = Color.LightGray
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
              text = "سلتك فارغة حالياً",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = PartyNavyDark
              )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "تصفح معارض ومنافذ حزب مستقبل وطن واحجز سلعك المدعمة الآن",
              style = MaterialTheme.typography.bodySmall.copy(
                color = Color.Gray,
                textAlign = TextAlign.Center
              ),
              modifier = Modifier.padding(horizontal = 24.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
              onClick = onDismiss,
              colors = ButtonDefaults.buttonColors(containerColor = PartyNavyPrimary),
              shape = RoundedCornerShape(12.dp)
            ) {
              Text("تصفح المعارض الآن")
            }
          }
        } else {
          // Non-empty Cart Content
          LazyColumn(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth()
          ) {
            // Cart Items
            items(cartItems) { item ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFC)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB))
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = item.productName,
                      style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = PartyNavyDark
                      )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                      text = item.outletLocation,
                      style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray),
                      maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(
                        text = "${item.unitPrice.toInt()} ج.م",
                        style = MaterialTheme.typography.bodyMedium.copy(
                          fontWeight = FontWeight.Bold,
                          color = Color(0xFF2E7D32)
                        )
                      )
                      if (item.originalPrice > item.unitPrice) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                          text = "${item.originalPrice.toInt()} ج.م",
                          style = MaterialTheme.typography.labelSmall.copy(
                            textDecoration = TextDecoration.LineThrough,
                            color = Color.Gray
                          )
                        )
                      }
                    }
                  }

                  // Quantity Controls
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                      .clip(RoundedCornerShape(20.dp))
                      .background(Color.White)
                      .border(1.dp, Color(0xFFD1D5DB), RoundedCornerShape(20.dp))
                      .padding(horizontal = 4.dp, vertical = 2.dp)
                  ) {
                    IconButton(
                      onClick = { onUpdateQuantity(item, item.quantity - 1) },
                      modifier = Modifier.size(28.dp)
                    ) {
                      Icon(
                        imageVector = if (item.quantity == 1) Icons.Default.Delete else Icons.Default.Remove,
                        contentDescription = "إنقاص",
                        tint = if (item.quantity == 1) Color.Red else PartyNavyDark,
                        modifier = Modifier.size(16.dp)
                      )
                    }
                    Text(
                      text = "${item.quantity}",
                      style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                      modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    IconButton(
                      onClick = { onUpdateQuantity(item, item.quantity + 1) },
                      modifier = Modifier.size(28.dp)
                    ) {
                      Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "زيادة",
                        tint = PartyNavyDark,
                        modifier = Modifier.size(16.dp)
                      )
                    }
                  }
                }
              }
            }

            // Promo Coupons section
            item {
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "الكوبونات وقسائم التخفيض الحزبية",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = PartyNavyDark
                )
              )
              Spacer(modifier = Modifier.height(6.dp))

              // Suggested coupon chips
              LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                items(availableCoupons) { coupon ->
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(12.dp))
                      .background(if (appliedCoupon?.code == coupon.code) PartyGoldAccent.copy(alpha = 0.2f) else Color(0xFFF3F4F6))
                      .border(
                        1.dp,
                        if (appliedCoupon?.code == coupon.code) PartyGoldAccent else Color(0xFFE5E7EB),
                        RoundedCornerShape(12.dp)
                      )
                      .clickable { onApplyCoupon(coupon.code) }
                      .padding(horizontal = 10.dp, vertical = 6.dp)
                  ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Icon(
                        imageVector = Icons.Default.Discount,
                        contentDescription = null,
                        tint = PartyNavyDark,
                        modifier = Modifier.size(14.dp)
                      )
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = coupon.code,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PartyNavyDark
                      )
                    }
                  }
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              // Input coupon field
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
              ) {
                OutlinedTextField(
                  value = couponInput,
                  onValueChange = { couponInput = it },
                  placeholder = { Text("أدخل كود الخصم (مثل: WATAN2026)", fontSize = 12.sp) },
                  modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp),
                  shape = RoundedCornerShape(12.dp),
                  singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                  onClick = {
                    if (couponInput.isNotBlank()) {
                      onApplyCoupon(couponInput)
                      couponInput = ""
                    }
                  },
                  colors = ButtonDefaults.buttonColors(
                    containerColor = PhosphorGreen,
                    contentColor = TextPrimaryDark
                  ),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.height(48.dp)
                ) {
                  Text("تطبيق", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                }
              }

              if (appliedCoupon != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(PhosphorGreenLight)
                    .padding(8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.CheckCircle,
                      contentDescription = null,
                      tint = PhosphorGreenDark,
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "${appliedCoupon.code}: ${appliedCoupon.description}",
                      fontSize = 11.sp,
                      color = PhosphorGreenDark,
                      fontWeight = FontWeight.Bold
                    )
                  }
                  Text(
                    text = "إلغاء",
                    fontSize = 11.sp,
                    color = Color.Red,
                    modifier = Modifier.clickable { onRemoveCoupon() }
                  )
                }
              }
            }

            // Delivery method
            item {
              Spacer(modifier = Modifier.height(14.dp))
              Text(
                text = "طريقة الاستلام والتوصيل",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimaryDark
                )
              )
              Spacer(modifier = Modifier.height(6.dp))

              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .background(if (deliveryType == "استلام من منفذ الحزب") PhosphorGreenLight else Color(0xFFF9FAFC))
                  .border(1.dp, if (deliveryType == "استلام من منفذ الحزب") PhosphorGreen else LightSkyBorder, RoundedCornerShape(12.dp))
                  .clickable { deliveryType = "استلام من منفذ الحزب" }
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                RadioButton(
                  selected = deliveryType == "استلام من منفذ الحزب",
                  onClick = { deliveryType = "استلام من منفذ الحزب" },
                  colors = RadioButtonDefaults.colors(selectedColor = PhosphorGreenDark)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                  imageVector = Icons.Default.Storefront,
                  contentDescription = null,
                  tint = PhosphorGreenDark
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = "استلام مباشر من شادر / منفذ الحزب",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = TextPrimaryDark
                  )
                  Text(
                    text = "مجاناً بدون أي مصاريف إضافية",
                    fontSize = 11.sp,
                    color = PhosphorGreenDark
                  )
                }
              }

              Spacer(modifier = Modifier.height(6.dp))

              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .background(if (deliveryType == "توصيل منزلي") PhosphorGreenLight else Color(0xFFF9FAFC))
                  .border(1.dp, if (deliveryType == "توصيل منزلي") PhosphorGreen else LightSkyBorder, RoundedCornerShape(12.dp))
                  .clickable { deliveryType = "توصيل منزلي" }
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                RadioButton(
                  selected = deliveryType == "توصيل منزلي",
                  onClick = { deliveryType = "توصيل منزلي" },
                  colors = RadioButtonDefaults.colors(selectedColor = PhosphorGreenDark)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                  imageVector = Icons.Default.LocalShipping,
                  contentDescription = null,
                  tint = PhosphorGreenDark
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = "توصيل للمنزل عبر أمانة العمل الجماهيري",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = PartyNavyDark
                  )
                  Text(
                    text = "رسوم رمزية 20 ج.م فقط دعماً للمواطنين",
                    fontSize = 11.sp,
                    color = Color.Gray
                  )
                }
              }
            }

            // Checkout Customer Form toggle
            item {
              Spacer(modifier = Modifier.height(14.dp))
              Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F4F8)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = "بيانات تأكيد الحجز والتواصل",
                      fontWeight = FontWeight.Bold,
                      fontSize = 13.sp,
                      color = PartyNavyDark
                    )
                    TextButton(onClick = { showCheckoutForm = !showCheckoutForm }) {
                      Text(if (showCheckoutForm) "إخفاء" else "تعديل البيانات")
                    }
                  }

                  AnimatedVisibility(visible = showCheckoutForm || customerName.isEmpty()) {
                    Column {
                      OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("الاسم بالكامل") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                      )
                      Spacer(modifier = Modifier.height(8.dp))
                      OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { if (it.length <= 11 && it.all { c -> c.isDigit() }) customerPhone = it },
                        label = { Text("رقم الهاتف (010...)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                      )
                      Spacer(modifier = Modifier.height(8.dp))
                      OutlinedTextField(
                        value = customerAddress,
                        onValueChange = { customerAddress = it },
                        label = { Text(if (deliveryType == "توصيل منزلي") "عنوان التوصيل بالتفصيل" else "المنفذ أو المنطقة المفضلة للاستلام") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                      )
                    }
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Divider(color = Color(0xFFE5E7EB))
          Spacer(modifier = Modifier.height(10.dp))

          // Savings Banner
          if (totalSavings > 0) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(PhosphorGreenLight)
                .padding(vertical = 6.dp, horizontal = 12.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "✨ إجمالي وفرك بفضل مبادرة مستقبل وطن: ${totalSavings.toInt()} ج.م ✨",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = PhosphorGreenDark
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
          }

          // Total and Checkout Action
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "الإجمالي المطلوب:",
                fontSize = 11.sp,
                color = Color.Gray
              )
              Text(
                text = "${finalTotal.toInt()} ج.م",
                style = MaterialTheme.typography.titleLarge.copy(
                  fontWeight = FontWeight.Bold,
                  color = TextPrimaryDark
                )
              )
            }

            Button(
              onClick = {
                onCheckout(
                  customerName,
                  customerPhone,
                  deliveryType,
                  customerAddress.ifBlank { "منفذ الحزب الرئيسي" },
                  cartItems.sumOf { it.quantity },
                  finalTotal,
                  totalSavings
                )
              },
              enabled = !isPlacingOrder,
              colors = ButtonDefaults.buttonColors(
                containerColor = PhosphorGreen,
                contentColor = TextPrimaryDark
              ),
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier
                .height(48.dp)
                .testTag("confirm_order_button")
            ) {
              if (isPlacingOrder) {
                CircularProgressIndicator(
                  modifier = Modifier.size(20.dp),
                  color = TextPrimaryDark,
                  strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("جاري التأكيد...", color = TextPrimaryDark, fontWeight = FontWeight.Bold)
              } else {
                Text(
                  text = "تأكيد الطلب والحجز الفوري",
                  fontWeight = FontWeight.Bold,
                  color = TextPrimaryDark
                )
              }
            }
          }
        }
      }
    }
  }
}
