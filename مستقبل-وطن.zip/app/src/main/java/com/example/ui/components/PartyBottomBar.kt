package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.PartyNavigationTab
import com.example.ui.theme.LightSkyBackground
import com.example.ui.theme.LightSkyBorder
import com.example.ui.theme.PhosphorGreenDark
import com.example.ui.theme.PhosphorGreenLight
import com.example.ui.theme.TextMuted

@Composable
fun PartyBottomBar(
  currentTab: PartyNavigationTab,
  onTabSelected: (PartyNavigationTab) -> Unit
) {
  NavigationBar(
    modifier = Modifier
      .height(72.dp)
      .border(0.8.dp, LightSkyBorder),
    containerColor = Color.White,
    tonalElevation = 4.dp
  ) {
    val items = listOf(
      NavigationItemData(PartyNavigationTab.HOME, "الرئيسية", Icons.Default.Home, "nav_home"),
      NavigationItemData(PartyNavigationTab.MARKETPLACE, "سوق المعارض", Icons.Default.ShoppingCart, "nav_marketplace"),
      NavigationItemData(PartyNavigationTab.INITIATIVES, "المبادرات", Icons.Default.VolunteerActivism, "nav_initiatives"),
      NavigationItemData(PartyNavigationTab.CITIZEN_SERVICE, "خدمة المواطنين", Icons.Default.Assignment, "nav_citizen_service"),
      NavigationItemData(PartyNavigationTab.MEMBERSHIP, "العضوية", Icons.Default.CardMembership, "nav_membership"),
      NavigationItemData(PartyNavigationTab.DEPUTIES, "النواب والمقرات", Icons.Default.People, "nav_deputies")
    )

    items.forEach { item ->
      val isSelected = currentTab == item.tab
      NavigationBarItem(
        selected = isSelected,
        onClick = { onTabSelected(item.tab) },
        modifier = Modifier.testTag(item.testTag),
        icon = {
          Icon(
            imageVector = item.icon,
            contentDescription = item.label,
            tint = if (isSelected) PhosphorGreenDark else TextMuted
          )
        },
        label = {
          Text(
            text = item.label,
            style = MaterialTheme.typography.labelSmall.copy(
              fontSize = 9.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) PhosphorGreenDark else TextMuted
            ),
            maxLines = 1
          )
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = PhosphorGreenDark,
          unselectedIconColor = TextMuted,
          indicatorColor = PhosphorGreenLight
        )
      )
    }
  }
}

private data class NavigationItemData(
  val tab: PartyNavigationTab,
  val label: String,
  val icon: ImageVector,
  val testTag: String
)
