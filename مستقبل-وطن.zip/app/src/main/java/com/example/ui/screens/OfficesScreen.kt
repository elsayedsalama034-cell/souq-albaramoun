package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PartyOffice
import com.example.ui.theme.PartyGoldAccent
import com.example.ui.theme.PartyGoldDark
import com.example.ui.theme.PartyNavyDark
import com.example.ui.theme.PartyNavyPrimary
import com.example.ui.theme.TextSecondaryDark

@Composable
fun OfficesScreen(
  offices: List<PartyOffice>
) {
  val context = LocalContext.current

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("offices_screen"),
    contentPadding = PaddingValues(bottom = 24.dp)
  ) {
    // Top banner
    item {
      Surface(
        color = PartyNavyDark,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
          Text(
            text = "المقر الرئيسي وأمانات المحافظات",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "تواجد حزبي وميداني في كافة المحافظات والمراكز والأقسام على مستوى الجمهورية",
            style = MaterialTheme.typography.bodySmall.copy(
              color = Color.White.copy(alpha = 0.8f),
              fontSize = 12.sp
            )
          )
        }
      }
    }

    // Central Hotline Quick Call Card
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(50.dp)
              .clip(CircleShape)
              .background(PartyGoldAccent.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.Phone,
              contentDescription = null,
              tint = PartyNavyDark,
              modifier = Modifier.size(26.dp)
            )
          }

          Spacer(modifier = Modifier.width(14.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "الخط الساخن المركزي للحزب",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
              text = "16543 (خدمة المواطنين على مدار اليوم)",
              style = MaterialTheme.typography.bodySmall.copy(color = TextSecondaryDark)
            )
          }

          Button(
            onClick = {
              val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:16543")
              }
              context.startActivity(intent)
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PartyNavyDark)
          ) {
            Text("اتصال", color = Color.White)
          }
        }
      }
    }

    // Offices list
    item {
      Text(
        text = "مقرات الأمانات بالمحافظات:",
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onBackground
        ),
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
      )
    }

    items(offices, key = { it.id }) { office ->
      OfficeCard(
        office = office,
        onCallClick = {
          val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${office.hotline}")
          }
          context.startActivity(intent)
        },
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
      )
    }
  }
}

@Composable
private fun OfficeCard(
  office: PartyOffice,
  onCallClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  ElevatedCard(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          color = PartyNavyPrimary.copy(alpha = 0.1f),
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = "محافظة ${office.governorate}",
            style = MaterialTheme.typography.labelSmall.copy(
              color = PartyNavyPrimary,
              fontWeight = FontWeight.Bold
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }

        IconButton(
          onClick = onCallClick,
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(PartyNavyDark)
        ) {
          Icon(
            Icons.Default.Call,
            contentDescription = "اتصال بالمقر",
            tint = Color.White,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = office.title,
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp
        )
      )

      Spacer(modifier = Modifier.height(6.dp))

      Row(verticalAlignment = Alignment.Top) {
        Icon(
          Icons.Default.LocationOn,
          contentDescription = null,
          tint = PartyGoldDark,
          modifier = Modifier
            .size(16.dp)
            .padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = office.address,
          style = MaterialTheme.typography.bodySmall.copy(
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
            lineHeight = 17.sp
          )
        )
      }

      Spacer(modifier = Modifier.height(4.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          Icons.Default.Person,
          contentDescription = null,
          tint = TextSecondaryDark,
          modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = office.secretaryName,
          style = MaterialTheme.typography.bodySmall.copy(
            color = TextSecondaryDark,
            fontSize = 11.sp
          )
        )
      }
    }
  }
}
