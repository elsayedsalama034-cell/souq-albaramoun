package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddBusiness
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.NewProductFormState
import com.example.ui.theme.PartyNavyDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProductDialog(
  formState: NewProductFormState,
  categories: List<String>,
  governorates: List<String>,
  onTitleChange: (String) -> Unit,
  onCategoryChange: (String) -> Unit,
  onOriginalPriceChange: (String) -> Unit,
  onDiscountedPriceChange: (String) -> Unit,
  onGovernorateChange: (String) -> Unit,
  onLocationChange: (String) -> Unit,
  onSellerNameChange: (String) -> Unit,
  onPhoneChange: (String) -> Unit,
  onWhatsappChange: (String) -> Unit,
  onDescriptionChange: (String) -> Unit,
  onMemberExclusiveChange: (Boolean) -> Unit,
  onSubmit: () -> Unit,
  onDismiss: () -> Unit
) {
  val scrollState = rememberScrollState()
  var catExpanded by remember { mutableStateOf(false) }
  var govExpanded by remember { mutableStateOf(false) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .heightIn(max = 680.dp)
        .clip(RoundedCornerShape(24.dp)),
      color = Color.White,
      tonalElevation = 8.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(scrollState)
          .padding(20.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AddBusiness,
              contentDescription = null,
              tint = PartyNavyDark,
              modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "عرض سلعة في سوق الحزب",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = PartyNavyDark
                )
              )
              Text(
                text = "دعماً للأسر المنتجة ومشروعات الشباب",
                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
              )
            }
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "إغلاق",
              tint = Color.Gray
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Title
        OutlinedTextField(
          value = formState.title,
          onValueChange = onTitleChange,
          label = { Text("عنوان السلعة أو المعروض") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Category Dropdown
        ExposedDropdownMenuBox(
          expanded = catExpanded,
          onExpandedChange = { catExpanded = !catExpanded },
          modifier = Modifier.fillMaxWidth()
        ) {
          OutlinedTextField(
            value = formState.category,
            onValueChange = {},
            readOnly = true,
            label = { Text("تصنيف السلعة") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
          )
          ExposedDropdownMenu(
            expanded = catExpanded,
            onDismissRequest = { catExpanded = false }
          ) {
            categories.filter { it != "الكل" }.forEach { cat ->
              DropdownMenuItem(
                text = { Text(cat) },
                onClick = {
                  onCategoryChange(cat)
                  catExpanded = false
                }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Prices Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = formState.discountedPrice,
            onValueChange = onDiscountedPriceChange,
            label = { Text("سعر البيع المخفض (ج.م)") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
          )
          OutlinedTextField(
            value = formState.originalPrice,
            onValueChange = onOriginalPriceChange,
            label = { Text("السعر الأصلي بالسوق") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Governorate & Location
        ExposedDropdownMenuBox(
          expanded = govExpanded,
          onExpandedChange = { govExpanded = !govExpanded },
          modifier = Modifier.fillMaxWidth()
        ) {
          OutlinedTextField(
            value = formState.governorate,
            onValueChange = {},
            readOnly = true,
            label = { Text("المحافظة") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = govExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
          )
          ExposedDropdownMenu(
            expanded = govExpanded,
            onDismissRequest = { govExpanded = false }
          ) {
            governorates.filter { it != "الكل" }.forEach { gov ->
              DropdownMenuItem(
                text = { Text(gov) },
                onClick = {
                  onGovernorateChange(gov)
                  govExpanded = false
                }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = formState.locationDetails,
          onValueChange = onLocationChange,
          label = { Text("العنوان / اسم المعرض أو الشادر") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = formState.sellerName,
          onValueChange = onSellerNameChange,
          label = { Text("اسم العارض أو اسم المشروع") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Phone & WhatsApp
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = formState.phoneNumber,
            onValueChange = onPhoneChange,
            label = { Text("رقم الهاتف (010...)") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
          )
          OutlinedTextField(
            value = formState.whatsappNumber,
            onValueChange = onWhatsappChange,
            label = { Text("رقم الواتساب") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = formState.description,
          onValueChange = onDescriptionChange,
          label = { Text("وصف السلعة والمواصفات ونسبة الدعم") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          minLines = 3
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Checkbox member exclusive
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Checkbox(
            checked = formState.isMemberExclusive,
            onCheckedChange = onMemberExclusiveChange,
            colors = CheckboxDefaults.colors(checkedColor = PartyNavyDark)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "توفير خصم إضافي خاص بحاملي كارنيه حزب مستقبل وطن",
            fontSize = 12.sp,
            color = PartyNavyDark
          )
        }

        if (formState.errorMessage != null) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = formState.errorMessage,
            color = Color.Red,
            fontSize = 12.sp
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
          onClick = onSubmit,
          enabled = !formState.isSubmitting,
          colors = ButtonDefaults.buttonColors(containerColor = PartyNavyDark),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
        ) {
          if (formState.isSubmitting) {
            CircularProgressIndicator(
              modifier = Modifier.size(20.dp),
              color = Color.White,
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("جاري النشر...")
          } else {
            Text(
              text = "نشر السلعة في سوق المعارض",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }
        }
      }
    }
  }
}
